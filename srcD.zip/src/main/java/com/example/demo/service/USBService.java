package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.usb.Usb;
import com.example.demo.usbRepository.UsbRepository;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Service
public class USBService {
	
	 @Autowired
	    private UsbRepository usbRepository;
	  
	 public List<String> getRemovableUSBDeviceNames() {
	    List<String> mountNames = new ArrayList<>();
	    try {
	        // Adjust the lsblk command to include MOUNTPOINT
	        String command = "/usr/bin/lsblk -o NAME,RM,MOUNTPOINT -p";
	        Process process = Runtime.getRuntime().exec(command);
	        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
	        String line;

	        while ((line = reader.readLine()) != null) {
	            if (line.contains("MOUNTPOINT") || line.trim().isEmpty()) {
	                continue; // Skip header or empty lines
	            }

	            // Split the line into parts: NAME, RM (removable flag), MOUNTPOINT
	            String[] parts = line.trim().split("\\s+");
	            if (parts.length < 3) {
	                continue; // Skip lines without enough data
	            }

	            String name = parts[0]; // Device/partition name
	            String removable = parts[1]; // Removable flag
	            String mountpoint = parts[2]; // Mountpoint

	            // Include only removable devices/partitions with a non-empty mountpoint
	            if ("1".equals(removable) && !mountpoint.trim().isEmpty() && !mountpoint.equals("-")) {
	                // Extract the last part of the mountpoint and normalize it
	                String mountName = mountpoint.substring(mountpoint.lastIndexOf('/') + 1).trim();
	                mountName = mountName.toLowerCase(); // Convert to lowercase
	                mountName = mountName.replaceAll("-+$", ""); // Remove trailing hyphens
	                mountNames.add(mountName);
	            }
	        }

	        reader.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	        mountNames.add("Error fetching USB details: " + e.getMessage());
	    }
	    return mountNames;
	}

    // Method to fetch all USB device names with labels
    public List<String> getAllRemovableUSBDevices() {
        List<String> removableUSBDevices = new ArrayList<>();
        try {
            String command = "/usr/bin/lsblk -o NAME,LABEL,RM -p"; // Fetch device names and labels
            Process process = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;

            while ((line = reader.readLine()) != null) {
                if (line.contains("NAME") || line.trim().isEmpty()) {
                    continue; // Skip header or empty lines
                }

                String[] parts = line.trim().split("\\s+");
                String name = parts[0]; // Device name
                String label = parts.length > 1 ? parts[1] : ""; // Device label
                String removable = parts.length > 2 ? parts[2] : "0"; // Removable flag

                // Include only removable devices
                if ("1".equals(removable)) {
                    String displayName = !label.isEmpty() ? label : name; // Use label if available, otherwise name
                    removableUSBDevices.add(displayName);
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
            removableUSBDevices.add("Error fetching USB details: " + e.getMessage());
        }
        return removableUSBDevices;
    }
	
	
    // Method to fetch the UUIDs of removable USB devices
    public List<String> getRemovableUSBDeviceUUIDs() {
        List<String> removableUSBUUIDs = new ArrayList<>();
        try {
            String command = "/usr/bin/lsblk -o UUID,NAME,RM -p"; // Include NAME to check for /dev/sr0
            Process process = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;

            while ((line = reader.readLine()) != null) {
                if (line.contains("MOUNTPOINT") || line.trim().isEmpty()) {
                    continue; // Skip header or empty lines
                }
int lastSpaceIndex=line.lastIndexOf(' ');
                String[] parts = line.trim().split("\\s+");
                String uuid = parts[0];  // UUID
                String mountpoint=  line.substring(0,lastSpaceIndex).trim();
                String removable = parts.length > 2 ? parts[2] : "0"; // Removable flag
String[] mountparts;
String name;
                // Include only removable devices with non-empty UUIDs, excluding /dev/sr0
                if ("1".equals(removable) && !mountpoint.trim().isEmpty() && !mountpoint.equals("-")) {
                    mountparts=mountpoint.split("/");
                    name=mountparts[mountparts.length-1];
                	removableUSBUUIDs.add(name);
                }
            }

            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
            removableUSBUUIDs.add("Error fetching USB details: " + e.getMessage());
        }
        return removableUSBUUIDs;
    }

    // Method to fetch the serial numbers of removable USB devices
    public List<String> getRemovableUSBDeviceSerials() {
        List<String> removableUSBSerials = new ArrayList<>();
        try {
            String command = "/usr/bin/lsblk -o SERIAL,NAME,RM -p"; // Include NAME to check for /dev/sr0
            Process process = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;

            while ((line = reader.readLine()) != null) {
                if (line.contains("SERIAL") || line.trim().isEmpty()) {
                    continue; // Skip header or empty lines
                }

                String[] parts = line.trim().split("\\s+");
                String serial = parts[0];  // Serial number
                String name = parts[1];   // Device name
                String removable = parts.length > 2 ? parts[2] : "0"; // Removable flag

                // Include only removable devices, excluding /dev/sr0
                if ("1".equals(removable) && !name.equals("/dev/sr0")) {
                    removableUSBSerials.add(serial);
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
            removableUSBSerials.add("Error fetching USB details: " + e.getMessage());
        }
        return removableUSBSerials;
    }
   
 // Method to register a USB device
  //  private final UsbRepository usbRepository;

    public boolean registerUSB(Usb usb) {
        if (usb == null || usb.getUsbname() == null || usb.getUuid() == null) {
            System.out.println("Invalid USB details. Registration failed.");
            return false;
        }
        try {
            usbRepository.save(usb);
            System.out.println("USB device registered successfully: " + usb);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
 // Method to fetch all USB details
    public List<Usb> getAllUsbDetails() {
        return usbRepository.findAll();
    }
    // Method to fetch all USB details
    public Usb getUsbDetailsById(Long usbId) {
        return usbRepository.findById(usbId).orElse(null);
    }
    //update usb details 
    public boolean updateUsbDetails(Long usbId, Usb usb) {
        if (usbRepository.existsById(usbId)) {
            usb.setId(usbId);
            usbRepository.save(usb);
            return true;
        }
        return false;
    }
    
    // Method to delete a USB by its ID
    public void deleteUsb(Long id) {
        usbRepository.deleteById(id);
    }
}