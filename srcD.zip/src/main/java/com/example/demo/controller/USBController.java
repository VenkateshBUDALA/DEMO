package com.example.demo.controller;
import com.example.demo.service.USBService;
import com.example.demo.usb.Usb;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usb")
public class USBController {
    private final USBService usbService;

    // Constructor injection for USBService
    public USBController(USBService usbService) {
        this.usbService = usbService;
    }

    // Endpoint to get removable USB device names
    @GetMapping("/names")
    public List<String> getUSBDeviceNames() {
        return usbService.getRemovableUSBDeviceNames();
    }

    // Endpoint to get removable USB device UUIDs
    @GetMapping("/uuids")
    public List<String> getUSBDeviceUUIDs() {
        return usbService.getRemovableUSBDeviceUUIDs();
    }

    // Endpoint to get removable USB device serials
    @GetMapping("/serials")
    public List<String> getUSBDeviceSerials() {
        return usbService.getRemovableUSBDeviceSerials();
    }

    // Endpoint to register a USB device
    @PostMapping("/register")
    public ResponseEntity<String> registerUSB(@RequestBody Usb usb) {
        try {
            boolean isRegistered = usbService.registerUSB(usb);
            if (isRegistered) {
                return ResponseEntity.ok("USB registered successfully!");
            } else {
                return ResponseEntity.badRequest().body("Failed to register USB.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body("An error occurred: " + e.getMessage());
        }
    }
    //fetching usbdetails 

    @GetMapping("/usbDetails")
    public List<Usb> getUsbDetails() {
        return usbService.getAllUsbDetails();
    }
    
 // Fetch USB details by ID
    @GetMapping("/usbDetails/{usbId}")
    public ResponseEntity<Usb> getUsbDetailsById(@PathVariable Long usbId) {
        Usb usb = usbService.getUsbDetailsById(usbId);
        if (usb != null) {
            return ResponseEntity.ok(usb);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    // Update USB details
    @PutMapping("/usbDetails/{usbId}")
    public ResponseEntity<String> updateUsbDetails(@PathVariable Long usbId, @RequestBody Usb usb) {
        boolean updated = usbService.updateUsbDetails(usbId, usb);
        if (updated) {
            return ResponseEntity.ok("USB updated successfully!");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to update USB details.");
        }
    }
    
    //delete usb 
    @DeleteMapping("/usbDetails/{id}")
    public ResponseEntity<Void> deleteUsb(@PathVariable Long id) {
        usbService.deleteUsb(id);  // Call the service to delete the USB
        return ResponseEntity.noContent().build();  // Return 204 No Content response
    }

}
