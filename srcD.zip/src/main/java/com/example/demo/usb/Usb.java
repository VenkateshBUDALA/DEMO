package com.example.demo.usb;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "usb_details")
public class Usb {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotEmpty(message = "USB name is required.")
    @Column(nullable = false)
    private String usbname;

    @NotEmpty(message = "UUID is required.")
    @Column(nullable = false, unique = true)
    private String uuid;

    @NotEmpty(message = "Serial number is required.")
    @Column(name = "serial_number", nullable = false, unique = false)
    private String serialNumber;

    @NotEmpty(message = "User is required.")
    @Column(nullable = false)
    private String user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.INACTIVE;

    @Column(name = "registration_time", updatable = false)
    private LocalDateTime registrationTime;

    public enum Status {
        ACTIVE("Active"),
        INACTIVE("Inactive"),
        BLOCKED("Blocked");

        private final String status;

        Status(String status) {
            this.status = status;
        }

        public String getStatus() {
            return status;
        }

        @Override
        public String toString() {
            return status;
        }
    }

    @PrePersist
    protected void onCreate() {
        registrationTime = LocalDateTime.now();
    }

    // Method to format registrationTime in 12-hour format for USB registration time
    public String getFormattedRegistrationTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss a");
        return registrationTime.format(formatter);
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsbname() {
        return usbname;
    }

    public void setUsbname(String usbname) {
        this.usbname = usbname;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public LocalDateTime getRegistrationTime() {
        return registrationTime;
    }

    public void setRegistrationTime(LocalDateTime registrationTime) {
        this.registrationTime = registrationTime;
    }
}
