package com.example.demo.usb;
import org.usb4java.*;

public class USBDeviceFetcher {
    public static void main(String[] args) {
        Context context = new Context();
        int result = LibUsb.init(context);
        if (result != LibUsb.SUCCESS) {
            throw new RuntimeException("Unable to initialize libusb. Result: " + result);
        }

        DeviceList deviceList = new DeviceList();
        try {
            result = LibUsb.getDeviceList(context, deviceList);
            if (result < 0) {
                throw new RuntimeException("Unable to get USB device list. Result: " + result);
            }

            for (Device device : deviceList) {
                DeviceDescriptor descriptor = new DeviceDescriptor();
                result = LibUsb.getDeviceDescriptor(device, descriptor);
                if (result != LibUsb.SUCCESS) {
                    throw new RuntimeException("Unable to read device descriptor. Result: " + result);
                }

                System.out.println("Vendor ID: " + descriptor.idVendor());
                System.out.println("Product ID: " + descriptor.idProduct());
                System.out.println("Serial Number Index: " + descriptor.iSerialNumber());
            }
        } finally {
            LibUsb.freeDeviceList(deviceList, true);
            LibUsb.exit(context);
        }
    }
}