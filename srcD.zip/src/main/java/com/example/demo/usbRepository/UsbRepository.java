package com.example.demo.usbRepository;

import com.example.demo.usb.Usb;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsbRepository extends JpaRepository<Usb, Long> {
}
