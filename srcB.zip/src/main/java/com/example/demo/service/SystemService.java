package com.example.demo.service;

import com.example.demo.model.DeviceSystem;
import com.example.demo.model.User;
import com.example.demo.repository.DeviceSystemRepository;
import com.example.demo.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class SystemService {

    private final DeviceSystemRepository systemRepository;

    @Autowired
    public SystemService(DeviceSystemRepository systemRepository) {
        this.systemRepository = systemRepository;
    }
    
    @Autowired
    private UserRepository userRepository;
    
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username); // Adjust based on your repository method
    }
    
    public DeviceSystem registerSystem(DeviceSystem deviceSystem) {
        // Additional validation or processing logic can be added here if needed
        return systemRepository.save(deviceSystem);
    }

    public DeviceSystem updateSystem(Long id, DeviceSystem updatedSystem) {
        // Find the existing system by ID
        DeviceSystem existingSystem = systemRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("System with ID " + id + " not found."));

        // Update fields of the existing system
        existingSystem.setSystemname(updatedSystem.getSystemname());
        existingSystem.setIpaddress(updatedSystem.getIpaddress());
        existingSystem.setMacaddress(updatedSystem.getMacaddress());
        existingSystem.setPolicyname(updatedSystem.getPolicyname());
        existingSystem.setUsername(updatedSystem.getUsername());

        // Save and return the updated system
        return systemRepository.save(existingSystem);
    }

    public DeviceSystem findById(Long id) {
        // Fetch the system details by ID
        return systemRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("System with ID " + id + " not found."));
    }
}
