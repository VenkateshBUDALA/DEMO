
package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.FileType;
import com.example.demo.repository.FileTypeRepository;
import java.util.List;

@Service
public class FileTypeService {

    @Autowired
    private FileTypeRepository fileTypeRepository;

    // Fetch all file types
    public List<FileType> getAllFileTypes() {
        return fileTypeRepository.findAll();
    }

    // Add a new file type
    public void addFileType(FileType fileType) {
        fileTypeRepository.save(fileType);
    }
    

    // Update file type
    public boolean updateFileType(Long id, FileType fileType) {
        if (fileTypeRepository.existsById(id)) {
            fileType.setId(id);
            fileTypeRepository.save(fileType);
            return true;
        }
        return false;
    }

    // Delete file type
    public boolean deleteFileType(Long id) {
        if (fileTypeRepository.existsById(id)) {
            fileTypeRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
