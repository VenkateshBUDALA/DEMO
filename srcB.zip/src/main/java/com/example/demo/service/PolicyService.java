package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Policy;
import com.example.demo.model.Role;
import com.example.demo.repository.PolicyRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class PolicyService {

    @Autowired
    private PolicyRepository policyRepository;

    // Save policy for update policy also
    public void savePolicy(Policy policy) {
        policyRepository.save(policy);
    }

    // Fetch all policies
    public List<Policy> getAllPolicies() {
        return policyRepository.findAll();  // Fetch all policies from the database
    }

    // In your PolicyService.java
    public List<String> getAllPolicyNames() {
        List<Policy> policies = policyRepository.findAll(); // Fetch all policies from the database
        List<String> policyNames = new ArrayList<>();
        
        for (Policy policy : policies) {
            policyNames.add(policy.getPolicyName());  // Assuming the Policy class has a getName() method
        }
        
        return policyNames;
    }

    // Delete policy
    public boolean deletePolicy(Long id) {
        if (policyRepository.existsById(id)) {
            policyRepository.deleteById(id);
            return true;
        }
        return false;
    }
    
    public Optional<Policy> getPolicyByid(Long id) {
        return policyRepository.findById(id);
    }
}
