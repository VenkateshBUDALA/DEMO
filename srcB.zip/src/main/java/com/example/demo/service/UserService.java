package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // Registration
    public User registerUser(User user) {
        return userRepository.save(user);
    }
   // Fetch all usernames only
    public List<String> getAllUsernames() {
        return userRepository.findAllUsernames();
    }
    // Fetching all user details
    public List<User> getAllUsers() {
        return userRepository.findAll(); // Return the full list of users
    }

    // Delete user by ID
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    // Fetch user by ID
    public User getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null); // Return null if not found
    }

    // Update user details
    public User updateUser(Long userId, User userDetails) {
        Optional<User> existingUser = userRepository.findById(userId);
        if (existingUser.isPresent()) {
            User user = existingUser.get();
            user.setUsername(userDetails.getUsername());
            user.setDepartmentDetails(userDetails.getDepartmentDetails());

            // If password is provided, encode it before saving
            if (userDetails.getPassword() != null && !userDetails.getPassword().isEmpty()) {
                user.setPassword(passwordEncoder.encode(userDetails.getPassword()));
            }

            return userRepository.save(user);
        }
        return null; // Or throw exception if user not found
    }
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

}
