package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
public class WebConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF as it's unnecessary for APIs that rely on token-based auth
            .csrf(csrf -> csrf.disable())
            
            // Enable CORS with global configuration
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            
            // Define authorization rules
            .authorizeHttpRequests(authorize -> authorize
                // Allow unrestricted access to specific endpoints (including /api/sys/register)
                .requestMatchers(
                    "/api/register",  // Ensure this is allowed
                    "/api/sys/register",  // Allow access to /api/sys/register
                    "/api/users", 
                    "/api/usernames", 
                    "/api/users/{id}",
                    "/api/{userId}",
                    "/api/users/{userId}",
                    "/public/**",
                    "/api/policies/filetypes",
                    "/api/policies/{id}",
                    "/api/policies",
                    "/api/sys/{id}",
                 "/api/sys/update/{id}"
                ).permitAll()  // These endpoints should be accessible without authentication
                
                // Require authentication for all other endpoints
                .anyRequest().authenticated()
            );
        
        return http.build();
    }
    
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        
        // Allow requests from specific origins (e.g., frontend app)
        configuration.setAllowedOrigins(List.of("http://localhost:3000"));
        
        // Define allowed HTTP methods
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        
        // Define allowed headers
        configuration.setAllowedHeaders(List.of("*"));
        
        // Allow credentials for session-based or cookie-based authentication
        configuration.setAllowCredentials(true);
        
        // Register the configuration globally
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        
        return source;
    }

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        // Provide a password encoder bean for encoding user passwords
        return new BCryptPasswordEncoder();
    }
}
