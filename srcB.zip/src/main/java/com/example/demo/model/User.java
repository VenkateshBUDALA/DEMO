//package com.example.demo.model;
//
//import jakarta.persistence.*;
//import java.time.LocalDateTime;
//
//@Entity
//public class User {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long userid;
//
//    @Column(nullable = false, unique = true)  // Added uniqueness and non-null constraints
//    private String username;
//
//    @Column(nullable = false)  // Ensuring password is not null
//    private String password;
//
//    @Embedded
//    private DepartmentDetails departmentDetails;
//
//    @Column(nullable = false, updatable = false) // Ensuring registration time is not updated
//    private LocalDateTime registrationTime;
//
//    // Constructor
//    public User() {
//        this.registrationTime = LocalDateTime.now(); // Set registration time to current time by default
//    }
//
//    // Getters and setters
//    public Long getUserid() {
//        return userid;
//    }
//
//    public void setUserid(Long userid) {
//        this.userid = userid;
//    }
//
//    public String getUsername() {
//        return username;
//    }
//
//    public void setUsername(String username) {
//        this.username = username;
//    }
//
//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }
//
//    public DepartmentDetails getDepartmentDetails() {
//        return departmentDetails;
//    }
//
//    public void setDepartmentDetails(DepartmentDetails departmentDetails) {
//        this.departmentDetails = departmentDetails;
//    }
//
//    public LocalDateTime getRegistrationTime() {
//        return registrationTime;
//    }
//
//    public void setRegistrationTime(LocalDateTime registrationTime) {
//        this.registrationTime = registrationTime;
//    }
//}
package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userid;

    @Column(nullable = false, unique = true)  // Ensuring username is unique and not null
    private String username;

    @Column(nullable = false)  // Ensuring password is not null
    private String password; // Note: Store hashed passwords for security

    @Embedded
    private DepartmentDetails departmentDetails; // Optional or mandatory based on your use case

    @Column(nullable = false, updatable = false) // Ensuring registration time is immutable
    private LocalDateTime registrationTime;

    // Default constructor
    public User() {
        // Default constructor for JPA
    }

    // Overloaded constructor for convenience
    public User(String username, String password, DepartmentDetails departmentDetails) {
        this.username = username;
        this.password = password;
        this.departmentDetails = departmentDetails;
    }

    // Lifecycle callback to set registrationTime automatically
    @PrePersist
    protected void onCreate() {
        this.registrationTime = LocalDateTime.now();
    }

    // Getters and setters
    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public DepartmentDetails getDepartmentDetails() {
        return departmentDetails;
    }

    public void setDepartmentDetails(DepartmentDetails departmentDetails) {
        this.departmentDetails = departmentDetails;
    }

    public LocalDateTime getRegistrationTime() {
        return registrationTime;
    }

    public void setRegistrationTime(LocalDateTime registrationTime) {
        this.registrationTime = registrationTime;
    }

	public String[] split(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean contains(String string) {
		// TODO Auto-generated method stub
		return false;
	}
}

