package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity
public class DeviceSystem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String systemname;
    private String ipaddress;
    private String macaddress;

    // Store policy name directly as a string
    private String policyname;

    // Store username directly as a string (use @Column to avoid conflicts)
    @Column(name = "username")
    private String username;

    // Assuming you have a User entity and a relationship with DeviceSystem
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = true) // Adjust the column name as per your database schema
    private User user;

    private LocalDateTime registrationTime;

    @Enumerated(EnumType.STRING)
    private Status status;

    // Default constructor
    public DeviceSystem() {
        this.registrationTime = LocalDateTime.now();
        this.status = Status.ACTIVE;
    }

    // Constructor with parameters
    public DeviceSystem(String systemname, String ipaddress, String macaddress, String username, String policyname) {
        this.systemname = systemname;
        this.ipaddress = ipaddress;
        this.macaddress = macaddress;
        this.username = username;
        this.policyname = policyname;
        this.registrationTime = LocalDateTime.now();
        this.status = Status.ACTIVE;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSystemname() {
        return systemname;
    }

    public void setSystemname(String systemname) {
        this.systemname = systemname;
    }

    public String getIpaddress() {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public String getMacaddress() {
        return macaddress;
    }

    public void setMacaddress(String macaddress) {
        this.macaddress = macaddress;
    }

    public String getPolicyname() {
        return policyname;
    }

    public void setPolicyname(String policyname) {
        this.policyname = policyname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LocalDateTime getRegistrationTime() {
        return registrationTime;
    }

    public void setRegistrationTime(LocalDateTime registrationTime) {
        this.registrationTime = registrationTime;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    // Enum for status
    public enum Status {
        ACTIVE,
        INACTIVE,
        BLOCKED
    }

    // Override toString() for better debugging
    @Override
    public String toString() {
        return "DeviceSystem{" +
                "id=" + id +
                ", systemname='" + systemname + '\'' +
                ", ipaddress='" + ipaddress + '\'' +
                ", macaddress='" + macaddress + '\'' +
                ", policyname='" + policyname + '\'' +
                ", username='" + username + '\'' +
                ", registrationTime=" + registrationTime +
                ", status=" + status +
                '}';
    }

    // Override equals() and hashCode() for comparing DeviceSystem objects
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DeviceSystem that = (DeviceSystem) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return 31;
    }
}
