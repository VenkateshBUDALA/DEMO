package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

@Embeddable
public class DepartmentDetails {

    @Column(nullable = false) // Ensuring department is not null
    private String department;

    private String unit;

    @Enumerated(EnumType.STRING) // Storing status as a string in the database
    @Column(nullable = false) // Ensuring status is not null
    private Status status;

    public DepartmentDetails() {
        this.status = Status.ACTIVE; // Default status if not provided
    }

    // Getters and setters
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    // Enum for status
    public enum Status {
        ACTIVE,
        INACTIVE,
        BLOCKED
    }

    // Override toString() for better debugging
    @Override
    public String toString() {
        return "DepartmentDetails{" +
                "department='" + department + '\'' +
                ", unit='" + unit + '\'' +
                ", status=" + status +
                '}';
    }
}
