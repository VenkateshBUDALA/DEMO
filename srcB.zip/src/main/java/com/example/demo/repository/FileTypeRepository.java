package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.FileType;

public interface FileTypeRepository extends JpaRepository<FileType, Long> {
	 Optional<FileType> findByName(String name);
}