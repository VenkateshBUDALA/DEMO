package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userService;
    
    // Registration
    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        User registeredUser = userService.registerUser(user);
        return ResponseEntity.ok(registeredUser);
    }

    // Fetching all users with full details (including department and other details)
    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userService.getAllUsers(); // Return full user objects instead of strings
    }
    //fetch all usernames only
    @GetMapping("/usernames")
    public List<String> getAllUsernames() {
        return userService.getAllUsernames();
    }
    // Delete user by ID
    @DeleteMapping("/users/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }

    // Get user details by userId
    @GetMapping("/users/{userId}")
    public User getUser(@PathVariable Long userId) {
        User user = userService.getUserById(userId);
        if (user != null) {
            return user;
        }
        throw new RuntimeException("User not found with id: " + userId); // Handle not found
    }

    // Update user details
    @PutMapping("/users/{userId}")
    public User updateUser(@PathVariable Long userId, @RequestBody User userDetails) {
        return userService.updateUser(userId, userDetails);
    }
}
