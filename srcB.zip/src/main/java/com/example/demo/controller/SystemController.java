package com.example.demo.controller;

import jakarta.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.Policy; // Adjust the package path as needed
import com.example.demo.model.DeviceSystem;
import com.example.demo.model.User;
import com.example.demo.repository.DeviceSystemRepository;
import com.example.demo.repository.PolicyRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.SystemService;
import com.example.demo.service.UserService;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/sys")
public class SystemController {

    @Autowired
    private DeviceSystemRepository systemRepository;

    @Autowired
    private SystemService systemService;

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> registerDevice(@RequestBody Map<String, Object> request) {
        try {
            System.out.println("Received request: " + request); // Log the entire request

            // Extract and validate fields
            String username = (String) request.get("user");
            if (username == null || username.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("User field is missing or empty.");
            }

            String systemname = (String) request.get("systemname");
            if (systemname == null || systemname.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("System name is missing or empty.");
            }

            String ipaddress = (String) request.get("ipaddress");
            if (ipaddress == null || ipaddress.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("IP address is missing or empty.");
            }

            String macaddress = (String) request.get("macaddress");
            if (macaddress == null || macaddress.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("MAC address is missing or empty.");
            }

            Object policyObj = request.get("policy");
            if (policyObj == null || !(policyObj instanceof Map)) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Policy field is missing or invalid.");
            }

            @SuppressWarnings("unchecked")
            Map<String, String> policyMap = (Map<String, String>) policyObj;
            String policyName = policyMap.get("policyName");
            if (policyName == null || policyName.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Policy name is missing or empty.");
            }

            // Save the device system
            DeviceSystem deviceSystem = new DeviceSystem();
            deviceSystem.setSystemname(systemname);
            deviceSystem.setIpaddress(ipaddress);
            deviceSystem.setMacaddress(macaddress);
            deviceSystem.setPolicyname(policyName); // Save policy name directly
            deviceSystem.setUsername(username);    // Save username directly

            DeviceSystem registeredSystem = systemService.registerSystem(deviceSystem);
            return ResponseEntity.status(HttpStatus.CREATED).body(registeredSystem);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }

    // Get all systems
    @GetMapping
    public List<DeviceSystem> getAllSystems() {
        return systemRepository.findAll();
    }
    //fetching sysdetails on update component
    @GetMapping("/{id}")
    public ResponseEntity<DeviceSystem> getSystemDetails(@PathVariable Long id) {
        try {
            DeviceSystem systemDetails = systemService.findById(id); // Fetch system details by ID
            if (systemDetails != null) {
                return new ResponseEntity<>(systemDetails, HttpStatus.OK); // Return the system details
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Return 404 if system not found
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); // Return 500 on error
        }
    }
    //update system details
    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateDeviceSystem(
            @PathVariable Long id,
            @RequestBody DeviceSystem updatedSystem) {

        return systemRepository.findById(id).map(existingSystem -> {
            existingSystem.setSystemname(updatedSystem.getSystemname());
            existingSystem.setIpaddress(updatedSystem.getIpaddress());
            existingSystem.setMacaddress(updatedSystem.getMacaddress());
            existingSystem.setPolicyname(updatedSystem.getPolicyname());
            existingSystem.setUsername(updatedSystem.getUsername());

            // Update the User reference if provided
            if (updatedSystem.getUser() != null) {
                existingSystem.setUser(updatedSystem.getUser());
            }

            systemRepository.save(existingSystem);
            return ResponseEntity.ok("Device system updated successfully!");
        }).orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Device system not found with id: " + id));
    }



    // Delete a system by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSystem(@PathVariable Long id) {
        Optional<DeviceSystem> system = systemRepository.findById(id);
        if (system.isPresent()) {
            systemRepository.deleteById(id);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
}
