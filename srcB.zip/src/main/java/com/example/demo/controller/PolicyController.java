package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.FileType;
import com.example.demo.model.Policy;
import com.example.demo.model.Role;
import com.example.demo.repository.PolicyRepository;
import com.example.demo.repository.RoleRepository;
import com.example.demo.service.FileTypeService;
import com.example.demo.service.PolicyService;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/policies")
public class PolicyController {

    @Autowired
    private PolicyService policyService;

    @Autowired
    private FileTypeService fileTypeService;
    
    @Autowired
    private PolicyRepository policyRepository;
    
    @Autowired
    private RoleRepository roleRepository;
    
    
    // Endpoint to fetch all policies
    @GetMapping
    public ResponseEntity<Object> getAllPolicies() {
        try {
            List<Policy> policies = policyService.getAllPolicies();
            if (policies.isEmpty()) {
                return new ResponseEntity<>(Map.of(
                    "message", "No policies found",
                    "data", policies
                ), HttpStatus.OK);
            }
            return new ResponseEntity<>(Map.of(
                "message", "Policies retrieved successfully",
                "data", policies
            ), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(Map.of(
                "message", "Failed to fetch policies",
                "error", e.getMessage()
            ), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // Endpoint to fetch a policy by id
    @GetMapping("/{id}")
    public ResponseEntity<Policy> getPolicyById(@PathVariable Long id) {
        Optional<Policy> policy = policyService.getPolicyByid(id);
        return policy.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                     .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Endpoint to fetch all file types
    @GetMapping("/filetypes")
    public ResponseEntity<List<FileType>> getFileTypes() {
        List<FileType> fileTypes = fileTypeService.getAllFileTypes();
        return new ResponseEntity<>(fileTypes, HttpStatus.OK);
    }

    // Endpoint to register a new policy
    @PostMapping
    public ResponseEntity<String> registerPolicy(@RequestBody Policy policy) {
        try {
            // Set the policy for all roles
            if (policy.getRoles() != null) {
                policy.setRoles(policy.getRoles());
            }

            // Save the policy (this will cascade and save roles as well)
            policyRepository.save(policy);

            return ResponseEntity.ok("Policy registered successfully!");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Failed to register policy: " + e.getMessage());
        }
    }

    // Endpoint to add a new file type
    @PostMapping("/filetypes")
    public ResponseEntity<String> addFileType(@RequestBody FileType fileType) {
        try {
            fileTypeService.addFileType(fileType);
            return new ResponseEntity<>("File type added successfully!", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to add file type: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Endpoint to update an existing policy
    @PutMapping("/{id}")
    public ResponseEntity<String> updatePolicy(@PathVariable Long id, @RequestBody Policy updatedPolicy) {
        try {
            // Fetch the existing policy
            Optional<Policy> existingPolicyOpt = policyService.getPolicyByid(id);
            if (existingPolicyOpt.isEmpty()) {
                return new ResponseEntity<>("Policy not found with id: " + id, HttpStatus.NOT_FOUND);
            }

            Policy existingPolicy = existingPolicyOpt.get();

            // Update the policy's fields
            existingPolicy.setPolicyName(updatedPolicy.getPolicyName());
            existingPolicy.setRegistrationTime(updatedPolicy.getRegistrationTime());

            // Update roles without replacing the collection
            if (updatedPolicy.getRoles() != null) {
                // Clear the existing roles
                existingPolicy.getRoles().clear();

                // Add updated roles to the existing collection
                for (Role role : updatedPolicy.getRoles()) {
                    role.setPolicy(existingPolicy); // Set the policy reference in the role
                    existingPolicy.getRoles().add(role);
                }
            }

            // Save the updated policy
            policyService.savePolicy(existingPolicy);

            return new ResponseEntity<>("Policy updated successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to update policy: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }




    // Endpoint to delete a policy by id
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePolicy(@PathVariable Long id) {
        try {
            boolean isDeleted = policyService.deletePolicy(id);
            if (isDeleted) {
                return new ResponseEntity<>("Policy deleted successfully!", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Policy not found with id: " + id, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to delete policy: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Endpoint to update an existing file type
    @PutMapping("/filetypes/{id}")
    public ResponseEntity<String> updateFileType(@PathVariable Long id, @RequestBody FileType fileType) {
        try {
            boolean isUpdated = fileTypeService.updateFileType(id, fileType);
            if (isUpdated) {
                return new ResponseEntity<>("File type updated successfully!", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("File type not found with id: " + id, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to update file type: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Endpoint to delete a file type by id
    @DeleteMapping("/filetypes/{id}")
    public ResponseEntity<String> deleteFileType(@PathVariable Long id) {
        try {
            boolean isDeleted = fileTypeService.deleteFileType(id);
            if (isDeleted) {
                return new ResponseEntity<>("File type deleted successfully!", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("File type not found with id: " + id, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to delete file type: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Endpoint to fetch all policy names only
    @GetMapping("/names")
    public ResponseEntity<List<String>> getAllPolicyNames() {
        try {
            List<String> policyNames = policyService.getAllPolicyNames(); // This should return a list of policy names as strings
            return new ResponseEntity<>(policyNames, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Optional: Global error handling
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(Exception e) {
        return new ResponseEntity<>("An error occurred: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
