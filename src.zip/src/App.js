import { BrowserRouter, Route, Routes } from 'react-router-dom';
import NavBarCom from './MyComponents/NavBarCom';
import SystemCom from './MyComponents/SystemCom';
import PolicyCom from './MyComponents/PolicyCom';
import UsbCom from './MyComponents/UsbCom';
import UpdateUser from './MyComponents/UpdateUser';
import UserReg from './MyComponents/UserReg';
import UpdateSystem from './MyComponents/UpdateSystem';
import UsbUpdate from './MyComponents/UpdateUsb';
import PolicyUpdate from './MyComponents/PolicyUpdate';
import UserDetails from './MyComponents/UserDetails';
import RemovableStorage from './MyComponents/RemovableStorage';
import SystemDetails from './MyComponents/SystemDetails';
import UsbDetails from './MyComponents/UsbDetails';
import PolicyDetails from './MyComponents/PolicyDetails';
import UserRegistrationTime from './MyComponents/UserRegistrationTime';
import PolicyRegistrationDetails from './MyComponents/PolicyRegistrationDetails';
import SystemRegistrationDetails from './MyComponents/SystemRegistrationDetails';
import UsbRegistrationTime from './MyComponents/UsbRegistrationTime';
import UpdateUsb from './MyComponents/UpdateUsb';
function App() {
  return (
    <div style={{ minHeight: "100vh", overflowX: "hidden" }}>
     <BrowserRouter>
        <div className="container-fluid h-100" style={{ padding: 0 }}>
          <div 
            style={{  
              display: 'flex', 
              minHeight: '100vh', 
              flexDirection: 'row', 
              width: '100%' // Ensures the width fits the screen
            }}
          >
            {/* Sidebar */}
            <div 
              style={{
                backgroundColor: '#ffffff',
                alignItems: 'center',
                display: 'flex',
                flexDirection: 'column',
                width: '100%',
                maxWidth: '300px', // Set a max width for the sidebar
                padding: '10px',
                boxSizing: 'border-box', // Ensures padding doesn't affect width
              }} 
              className="col-12 col-md-2 text-white"
            >
              <NavBarCom />
            </div>

            {/* Main Content */}
            <div 
              style={{
                backgroundColor: '#d4f6f7',
                alignItems: 'center',
                display: 'flex',
                flexDirection: 'column',
                flexGrow: 1, // Allows this section to take remaining space
                padding: '10px',
                boxSizing: 'border-box', // Ensures padding doesn't break layout
              }} 
              className="col-12 col-md-8"
            >
              <Routes>
                <Route path="/" element={<RemovableStorage />} />
                <Route path="/userDetails" element={<UserDetails />} />
                <Route path="/userRegistrationTime" element={<UserRegistrationTime />}/>
                <Route path="/usbRegistrationTime" element={<UsbRegistrationTime />}/>
                <Route path="/systemDetails" element={<SystemDetails />} />
                <Route path="/SystemRegistrationDetails" element={<SystemRegistrationDetails />}/>
                <Route path="/updateUsb/:usbId" element={<UpdateUsb />} />

               

                <Route path="/usbDetails" element={<UsbDetails />} />
                <Route path="/policyDetails" element={<PolicyDetails />} />
                <Route path="/UserReg" element={<UserReg />} />
                <Route path="/SystemCom" element={<SystemCom />} />
                <Route path="/UsbCom" element={<UsbCom />} />
                <Route path="/UserReg" element={<UserReg />} />
                <Route path="/PolicyCom" element={<PolicyCom />} />
                <Route path="/UpdateUser/:userid" element={<UpdateUser/>} />
                <Route path="/update-system/:systemId" element={<UpdateSystem />} />

                <Route path="/usbUpdate/:usbname" element={<UsbUpdate />} />
                <Route path="/PolicyUpdate/:policyId" element={<PolicyUpdate />} />
                <Route path="/PolicyRegistrationDetails" element={<PolicyRegistrationDetails />} />                <Route path="*" element={<h1>Page Not Found</h1>} />
              </Routes>
            </div>
          </div>
        </div>
      </BrowserRouter>
    </div>
  );
}
export default App;