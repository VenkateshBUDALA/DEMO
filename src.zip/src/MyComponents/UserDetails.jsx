import React, { useState, useEffect } from 'react';
import Pagination from 'react-js-pagination';
import { useNavigate } from 'react-router-dom';

const UserDetails = () => {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [activePage, setActivePage] = useState(1);
  const usersPerPage = 5;
  const navigate = useNavigate();

  // Fetch users from the backend
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/users'); // Replace with your backend URL
        if (!response.ok) {
          throw new Error(`Error fetching users: ${response.statusText}`);
        }
        const data = await response.json();
        setUsers(data); // Set full user objects
        setFilteredUsers(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching users:', error);
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  // Handle search input
  const handleSearch = (e) => {
    const term = e.target.value.toLowerCase();
    setSearchTerm(term);

    if (term === '') {
      setFilteredUsers(users);
    } else {
      const matchedUsers = users.filter((user) =>
        user.username.toLowerCase().includes(term)
      );
      const unmatchedUsers = users.filter(
        (user) => !user.username.toLowerCase().includes(term)
      );
      setFilteredUsers([...matchedUsers, ...unmatchedUsers]);
    }
  };

  // Pagination logic
  const indexOfLastUser = activePage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;
  const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);

  const handlePageChange = (pageNumber) => {
    setActivePage(pageNumber);
  };

  const handleAddUser = () => {
    navigate('/UserReg');
  };

  const handleMoreDetails = (user) => {
    navigate('/userRegistrationTime', { state: { ...user } });
  };

  const handleDeleteUser = async (userId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this user?");
  
    if (confirmDelete) {
      try {
        const response = await fetch(`http://localhost:8080/api/users/${userId}`, {
          method: 'DELETE',
        });
  
        if (response.ok) {
          setUsers(users.filter((user) => user.userid !== userId));
          setFilteredUsers(filteredUsers.filter((user) => user.userid !== userId));
        } else {
          console.error('Error deleting user:', response.statusText);
        }
      } catch (error) {
        console.error('Error deleting user:', error);
      }
    }
  };
  
  const handleUpdateUser = (userId) => {
    navigate(`/updateUser/${userId}`);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container-fluid p-4">
      <div className="row my-3">
        <div className="col-md-4"></div>
        <div className="col-md-4"></div>
        <div className="col-md-4">
          <button className="btn btn-danger text-black">U N B L O C K</button>
        </div>
      </div>

      <div className="row my-3">
        <div className="col-md-4">
          <h4>USER DETAILS</h4>
        </div>
        <div className="col-md-4">
          <input
            type="text"
            className="form-control"
            placeholder="Search by Username"
            value={searchTerm}
            onChange={handleSearch}
            style={{ width: '300px' }}
          />
        </div>
        <div className="col-md-4">
          <button className="btn btn-primary" onClick={handleAddUser}>
            Add User
          </button>
        </div>
      </div>

      {/* User Table */}
      <div className="row">
        <div className="col-md-12">
          <div className="table-responsive" style={{ maxHeight: '400px', overflowY: 'auto' }}>
            <table className="table table-bordered table-hover">
              <thead className="thead-dark">
                <tr>
                  <th style={{ width: '5%' }}>S.No</th>
                  <th style={{ width: '15%' }}>User Name</th>
                  <th style={{ width: '15%' }}>Department</th>
                  <th style={{ width: '15%' }}>Unit</th>
                  <th style={{ width: '10%' }}>Status</th>
                  <th style={{ width: '30%' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentUsers.map((user, index) => (
                  <tr
                    key={user.userid}
                    style={{
                      backgroundColor: user.username.toLowerCase().includes(searchTerm)
                        ? 'lightgray'
                        : 'transparent',
                    }}
                  >
                    <td>{indexOfFirstUser + index + 1}</td>
                    <td>{user.username}</td>
                    <td>{user.departmentDetails?.department || 'N/A'}</td>
                    <td>{user.departmentDetails?.unit || 'N/A'}</td>
                    <td>{user.departmentDetails?.status || 'N/A'}</td>
                    <td>
                      <button
                        className="btn btn-success btn-sm me-2"
                        onClick={() => handleMoreDetails(user)}
                      >
                        More Details
                      </button>
                      <button
                        className="btn btn-warning btn-sm me-2"
                        onClick={() => handleUpdateUser(user.userid)}
                      >
                        Update
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDeleteUser(user.userid)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      <div className="row">
        <div className="col-12 d-flex justify-content-end">
          <Pagination
            activePage={activePage}
            itemsCountPerPage={usersPerPage}
            totalItemsCount={filteredUsers.length}
            pageRangeDisplayed={5}
            onChange={handlePageChange}
            itemClass="page-item"
            linkClass="page-link"
          />
        </div>
      </div>
    </div>
  );
};

export default UserDetails;
