import React, { useState } from 'react';
import axios from 'axios';

const FetchData = ({ onFetchUuids, onFetchSerialNumber }) => {
    const [uuidList, setUuidList] = useState([]);
    const [serialNumbers, setSerialNumbers] = useState([]);
    const [selectedSerialNumber, setSelectedSerialNumber] = useState('');
    const [error, setError] = useState('');

    // Fetch Serial Numbers
    const fetchSerialNumbers = async () => {
        try {
            const response = await axios.get("http://localhost:8080/api/serials");
            setSerialNumbers(response.data); // Assuming response.data is an array of serial numbers
            setError(''); // Clear any previous errors
        } catch (error) {
            console.error("Error fetching serial numbers:", error);
            setError("Failed to fetch serial numbers.");
        }
    };
    //abc

    // Fetch UUIDs for a selected Serial Number
    const fetchUuidsForSerialNumber = async (serialNumber) => {
        try {
            const response = await axios.get(`http://localhost:8080/api/uuids/${serialNumber}`);
            setUuidList(response.data); // Assuming response.data is an array of UUIDs for the serial number
            onFetchUuids(response.data); // Notify the parent about the fetched UUIDs
            setError(''); // Clear any previous errors
        } catch (error) {
            console.error("Error fetching UUIDs:", error);
            setError("Failed to fetch UUIDs for the selected serial number.");
        }
    };

    return (
        <div>
            {/* Fetch Button */}
            <button 
                className="btn btn-secondary p-1" 
                onClick={fetchSerialNumbers}
                style={{ marginTop: '-155px', marginLeft: '180px' }}
            >
                Fetch
            </button>

            {/* Display Serial Numbers */}
            {serialNumbers.length > 0 && (
                <div>
                    <h4>Select a Serial Number</h4>
                    <ul>
                        {serialNumbers.map((serial, index) => (
                            <li 
                                key={index} 
                                style={{ cursor: 'pointer', padding: '5px', borderBottom: '1px solid #ccc' }}
                                onClick={() => {
                                    setSelectedSerialNumber(serial);
                                    fetchUuidsForSerialNumber(serial);
                                    onFetchSerialNumber(serial); // Notify the parent about the selected serial number
                                }}
                            >
                                {serial}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {/* Display UUIDs for Selected Serial Number */}
            {selectedSerialNumber && (
                <div>
                    <h4>UUIDs for Serial Number: {selectedSerialNumber}</h4>
                    <ul>
                        {uuidList.length > 0 ? (
                            uuidList.map((uuid, index) => <li key={index}>{uuid}</li>)
                        ) : (
                            <p>No UUIDs found for this serial number.</p>
                        )}
                    </ul>
                </div>
            )}

            {/* Display Error Messages */}
            {error && <p style={{ color: 'red' }}>{error}</p>}
        </div>
    );
};
export default FetchData;
