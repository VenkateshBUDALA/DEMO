import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const UsbCom = () => {
    const [usbDetails, setUsbDetails] = useState({
        usbname: '',
        Uuid: '',
        serialNumber: '',
        user: ''  // Add user field
    });
    const [usbNames, setUsbNames] = useState([]);
    const [serialNumbers, setSerialNumbers] = useState([]);
    const [uuids, setUuids] = useState([]);
    const [userNames, setUserNames] = useState([]); // State for user names
    const [error, setError] = useState('');
    
    const navigate = useNavigate();

    useEffect(() => {
        fetchUsbNames();
        fetchUuids();
        fetchUserNames();  // Fetch usernames when the component is mounted
    }, []);

    // Fetch Serial Numbers
    const fetchSerialNumbers = async () => {
        try {
            const response = await axios.get("http://localhost:8082/api/usb/serials");
            setSerialNumbers(response.data);
            setError('');
        } catch (error) {
            console.error("Error fetching serial numbers:", error);
            setError("Failed to fetch serial numbers.");
        }
    };

    // Fetch UUIDs
    const fetchUuids = async () => {
        try {
            const response = await axios.get("http://localhost:8082/api/usb/names");
            setUuids(response.data);
            setError('');
        } catch (error) {
            console.error("Error fetching UUIDs:", error);
            setError("Failed to fetch UUIDs.");
        }
    };

    // Fetch USB names from backend
    const fetchUsbNames = async () => {
        try {
            const response = await axios.get("http://localhost:8080/api/usb/names");
            if (response.status === 200) {
                setUsbNames(response.data);
            }
        } catch (error) {
            console.error("Error fetching USB names:", error);
            setError("Failed to load USB names.");
        }
    };

    // Fetch Usernames from backend
    const fetchUserNames = async () => {
        try {
            const response = await axios.get("http://localhost:8080/api/users");
            if (response.status === 200) {
                const usernames = response.data.map(user => user.username);  // Extract usernames
                setUserNames(usernames || []);
            } else {
                setError("Failed to load user details.");
            }
        } catch (error) {
            console.error("Error fetching usernames:", error);
            setError("Failed to load usernames.");
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUsbDetails(prevDetails => ({ ...prevDetails, [name]: value }));
    };

    const handleRegister = async (e) => {
        e.preventDefault();
    
        if (usbDetails.usbname.length < 5) {
            setError("USB Name must be at least 5 characters long.");
            return;
        }
        if (usbDetails.serialNumber.length < 5) {
            setError("Serial Number must be at least 5 characters long.");
            return;
        }
    
        const usbData = {
            usbname: usbDetails.usbname,
            uuid: usbDetails.Uuid,
            serialNumber: usbDetails.serialNumber,
            user: usbDetails.user  // Include user in the data
        };
    
        try {
            console.log("Sending USB registration data:", usbData); // Debugging log
            const response = await axios.post("http://localhost:8082/api/usb/register", usbData);
            if (response.status === 200) {
                alert("Registration successful!");
                navigate('/usbDetails');
                setUsbDetails({ usbname: '', Uuid: '', serialNumber: '', user: '' }); // Clear the form
                fetchUsbNames(); // Refresh USB names
            } else {
                setError("Registration failed. Please try again.");
            }
        } catch (error) {
            console.error("Error registering USB:", error);
            setError(error.response?.data?.message || "An error occurred. Please try again.");
        }
    };    

    return (
        <div className="jumbotron p-5 my-5 bg-white rounded">
            <h1>USB REGISTRATION</h1>
            <form onSubmit={handleRegister}>
                <div className='v'>
                    <input 
                        type="text"  
                        placeholder="USB Name" 
                        name="usbname"
                        value={usbDetails.usbname}
                        onChange={handleChange}
                        required     
                    />
                </div>

                <div className='v'>
                    <select
                        name="user"
                        value={usbDetails.user}
                        onChange={handleChange}
                        style={{ width: '220px' }}
                        required
                    >
                        <option value="">Select Username</option>
                        {userNames.map((username, index) => (
                            <option key={index} value={username}>{username}</option>
                        ))}
                    </select>
                </div>
                <div className='v'>
                    <select name="serialNumber" value={usbDetails.serialNumber} onChange={handleChange} style={{ width: '150px', marginRight: '70px' }}>
                        <option value="">SerialNumber</option>
                        {serialNumbers.map((serial, index) => (
                            <option key={index} value={serial}>{serial}</option>
                        ))}
                    </select>
                </div>
                <div className='v'>
                    <select name="Uuid" value={usbDetails.Uuid} onChange={handleChange} style={{ width: '150px', marginRight: '70px' }}>
                        <option value="">Select UUID</option>
                        {uuids.map((uuid, index) => (
                            <option key={index} value={uuid}>{uuid}</option>
                        ))}
                    </select>
                </div>
               
                <button 
                    className="btn btn-secondary p-3" 
                    onClick={() => { 
                        fetchSerialNumbers(); 
                        fetchUuids(); 
                    }}
                    style={{ marginTop: '-110px', marginLeft: '170px' }}
                >
                    Fetch
                </button>
                <div style={{ marginTop: '10px' }}>
                    <button type="submit" className="btn btn-success">REGISTER</button>
                </div>
            </form>
            {error && <p style={{ color: 'red' }}>{error}</p>}
        </div>
    );
};

export default UsbCom;
