import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const UpdateSystem = () => {
    const { systemId } = useParams(); // Get systemId from the URL parameters
    const navigate = useNavigate();

    const [systemDetails, setSystemDetails] = useState({
        systemname: '',
        ipaddress: '',
        macaddress: '',
        policy: '',
        userId: ''
    });
    const [error, setError] = useState('');
    const [policyNames, setPolicyNames] = useState([]); // Default to an empty array
    const [userNames, setUserNames] = useState([]);

    // Fetch policy names and user names
    useEffect(() => {
        const fetchData = async () => {
            try {
                const [policyResponse, userResponse] = await Promise.all([
                    axios.get("http://localhost:8080/api/policies/names"),
                    axios.get("http://localhost:8080/api/users")
                ]);

                if (policyResponse.status === 200) {
                    setPolicyNames(policyResponse.data || []);
                } else {
                    setError("Failed to load policy names.");
                }

                if (userResponse.status === 200) {
                    const usernames = userResponse.data.map(user => user.username);
                    setUserNames(usernames || []);
                } else {
                    setError("Failed to load user details.");
                }
            } catch (error) {
                console.error("Error fetching data:", error);
                setError("Failed to load data. Please try again.");
            }
        };

        fetchData();
    }, []);

    // Fetch system details based on systemId
    useEffect(() => {
        const fetchSystemDetails = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/api/sys/${systemId}`);
                if (response.status === 200) {
                    const data = response.data;
                    setSystemDetails({
                        systemname: data.systemname || '',
                        ipaddress: data.ipaddress || '',
                        macaddress: data.macaddress || '',
                        policy: data.policyname || '',
                        userId: data.username || ''
                    });
                } else {
                    setError("Failed to fetch system details.");
                }
            } catch (error) {
                console.error("Error fetching system details:", error);
                setError("Failed to fetch system details.");
            }
        };

        if (systemId) {
            fetchSystemDetails();
        } else {
            setError("System ID is missing.");
        }
    }, [systemId]);

    // Handle form submission for updating the system
    const handleUpdate = async (e) => {
        e.preventDefault();

        const { systemname, ipaddress, macaddress, policy, userId } = systemDetails;
        if (!systemname || !ipaddress || !macaddress || !policy || !userId) {
            setError("Please fill all required fields.");
            return;
        }

        try {
            const updatedSystem = {
                systemname,
                ipaddress,
                macaddress,
                policyname: policy, // Use the correct field name
                username: userId,  
            };

            const response = await axios.put(
                `http://localhost:8080/api/sys/update/${systemId}`,
                updatedSystem,
                { headers: { "Content-Type": "application/json" } }
            );

            if (response.status === 200) {
                alert("System updated successfully!");
                navigate(`/SystemDetails`);
            } else {
                setError("Failed to update system.");
            }
        } catch (error) {
            console.error("Error updating system:", error);
            setError("Failed to update system. Please try again.");
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setSystemDetails((prevDetails) => ({ ...prevDetails, [name]: value }));
    };

    return (
        <div className="jumbotron p-5 my-5 bg-white rounded">
            <h1 className="v">SYSTEM UPDATION</h1>

            <form onSubmit={handleUpdate}>
                <div className='v'>
                    <input
                        type="text"
                        name="systemname"
                        placeholder="System Name"
                        value={systemDetails.systemname}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div className='v'>
                    <input
                        type="text"
                        name="ipaddress"
                        placeholder="IP Address"
                        value={systemDetails.ipaddress}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div className='v'>
                    <input
                        type="text"
                        name="macaddress"
                        placeholder="MAC Address"
                        value={systemDetails.macaddress}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div className='v'>
                    <select
                        style={{ width: '220px' }}
                        name="policy"
                        value={systemDetails.policy}
                        onChange={handleInputChange}
                        required
                    >
                        <option value="">Select Policy</option>
                        {policyNames.map((policyName, index) => (
                            <option key={index} value={policyName}>
                                {policyName}
                            </option>
                        ))}
                    </select>
                </div>
                <div className='v'>
                    <select
                        style={{ width: '220px' }}
                        name="userId"
                        value={systemDetails.userId}
                        onChange={handleInputChange}
                        required
                    >
                        <option value="">Select User</option>
                        {userNames.map((user, index) => (
                            <option key={index} value={user}>
                                {user}
                            </option>
                        ))}
                    </select>
                </div>

                {error && <p style={{ color: 'red' }}>{error}</p>}

                <div className="v" style={{ display: 'flex', justifyContent: 'center' }}>
                    <button className="btn btn-success" type="submit">UPDATE</button>
                </div>
            </form>
        </div>
    );
};

export default UpdateSystem;
