import React from 'react';
import { useLocation } from 'react-router-dom';

const SystemRegistrationDetails = () => {
  const location = useLocation();
  const system = location.state;

  if (!system) {
    return <p>No system data available.</p>;
  }

  return (
    <div className="container p-4">
      <div className="card my-5">
        <div className="card-header bg-primary text-white">
          <h2>System Registration Details</h2>
        </div>
        <div className="card-body">
          <p><strong>System Name:</strong> {system.systemname || 'N/A'}</p>
          <p><strong>IP Address:</strong> {system.ipaddress || 'N/A'}</p>
          <p><strong>MAC Address:</strong> {system.macaddress || 'N/A'}</p>
          <p><strong>Policy:</strong> {system.policyname || 'N/A'}</p>
          <p><strong>Status:</strong> {system.status || 'N/A'}</p>
          <p><strong>Registration Time:</strong> 
            {system.registrationTime
              ? new Date(system.registrationTime).toLocaleString()
              : 'Not Available'}
          </p>
          <p><strong>Username:</strong> {system.username || 'N/A'}</p>
        </div>
      </div>
    </div>
  );
};

export default SystemRegistrationDetails;
