import React, { useState, useEffect } from "react";
import { Modal } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import "./policy.css";

const PolicyUpdate = () => {
  const navigate = useNavigate();
  const { policyId } = useParams(); // Fetch policyId from the URL

  const [policyName, setPolicyName] = useState("");
  const [fileTypes, setFileTypes] = useState([]);
  const [roles, setRoles] = useState({
    group: { permission: "", extensions: [] },
    owner: { permission: "", extensions: [] },
    guest: { permission: "", extensions: [] },
  });
  const [selectedRole, setSelectedRole] = useState("");  // Track selected role
  const [showModal, setShowModal] = useState(false);
  const [newExtension, setNewExtension] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    if (policyId) {
      fetchPolicyDetails();
    } else {
      setError("No policy selected.");
    }
  }, [policyId]);

  const fetchPolicyDetails = async () => {
    try {
      const { data } = await axios.get(
        `http://localhost:8080/api/policies/${policyId}`
      );

      setPolicyName(data.policyName || "");

      const defaultRoles = {
        group: { permission: "", extensions: [] },
        owner: { permission: "", extensions: [] },
        guest: { permission: "", extensions: [] },
      };

      data.roles.forEach((role) => {
        if (defaultRoles[role.role]) {
          defaultRoles[role.role] = {
            permission: role.permission || "",
            extensions: role.extensions || [],
          };
        }
      });

      setRoles(defaultRoles);
    } catch (err) {
      console.error("Error fetching policy details:", err);
      setError("Failed to fetch policy details.");
    }
  };

  // Fetch File Extensions from the backend API
  const fetchFileExtensions = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/policies/filetypes");
      setFileTypes(response.data);
    } catch (error) {
      console.error("Error fetching file extensions:", error);
    }
  };
  
  useEffect(() => {
    fetchFileExtensions();
  }, []);

  // Handle File Type Selection
  const handleFileTypeChange = (fileType) => {
    setRoles((prevRoles) => {
      const updatedExtensions = prevRoles[selectedRole].extensions.includes(fileType)
        ? prevRoles[selectedRole].extensions.filter((ext) => ext !== fileType)
        : [...prevRoles[selectedRole].extensions, fileType];

      return {
        ...prevRoles,
        [selectedRole]: { ...prevRoles[selectedRole], extensions: updatedExtensions },
      };
    });
  };

  // Handle Done Button
  const handleDone = () => {
    if (roles[selectedRole].permission !== "DENY" && roles[selectedRole].extensions.length === 0) {
      setError("Please select at least one file type.");
      return;
    }
    setError("");
    setShowModal(false);
  };

  // Handle adding a new extension
  const handleAddExtension = async () => {
    if (newExtension.trim() && !fileTypes.some(ft => ft.name === newExtension.trim())) {
      try {
        const newFileType = { name: newExtension.trim() };
        await axios.post("http://localhost:8080/api/policies/filetypes", newFileType);
        setFileTypes((prev) => [...prev, newFileType]);
        setNewExtension("");
      } catch (error) {
        console.error("Error adding new extension:", error);
        alert("Failed to add new extension. Please try again.");
      }
    } else if (fileTypes.some(ft => ft.name === newExtension.trim())) {
      alert("Extension already exists!");
    }
  };

  const updatePolicy = async () => {
    if (!policyName.trim()) {
      setError("Policy name cannot be empty.");
      return;
    }
  
    // Remove empty extensions from roles
    const cleanedRoles = Object.keys(roles).map((role) => ({
      role: role,
      permission: roles[role].permission,
      extensions: roles[role].extensions.filter((ext) => ext.trim() !== ""),
    }));
  
    try {
      const payload = {
        policyName,
        roles: cleanedRoles, // Send roles as an array of objects
      };
  
      console.log("Payload being sent:", payload);
  
      const { status, data } = await axios.put(
        `http://localhost:8080/api/policies/${policyId}`,
        payload
      );
  
      if (status === 200) {
        setSuccess("Policy updated successfully.");
        alert("Policy updated successfully.");
        navigate("/PolicyDetails");
      } else {
        setError(`Failed to update policy. Status code: ${status}`);
      }
    } catch (err) {
      console.error("Error updating policy:", err);
      setError(`Failed to update policy. ${err.response ? err.response.data : err.message}`);
    }
  };
  

  return (
    <div className="jumbotron p-5 my-5 bg-white rounded">
         <h1 className="v">POLICY UPDATION</h1>
      <div className="v">
        <input
          type="text"
          placeholder="Policy Name"
          value={policyName}
          onChange={(e) => setPolicyName(e.target.value)}
          required
        />
      </div>

      {["group", "owner", "guest"].map((role) => (
        <div key={role} className="role-section">
          <label style={{ marginTop: "20px", marginRight: "250px" }}>{role.toUpperCase()}</label>
          <div
            className="role-actions"
            style={{
              display: "flex",
              flexDirection: "row",
              gap: "20px",
              marginTop: "-30px",
              marginLeft: "100px",
              alignItems: "center",
            }}
          >
            <select
              value={roles[role]?.permission}
              onChange={(e) =>
                setRoles((prevRoles) => ({
                  ...prevRoles,
                  [role]: {
                    ...prevRoles[role],
                    permission: e.target.value,
                  },
                }))
              }
            >
              <option value="">Select Permission</option>
              <option value="READ">READ</option>
              <option value="WRITE">WRITE</option>
              <option value="BOTH">BOTH</option>
              <option value="DENY">DENY</option>
            </select>
            <button className="btn btn-secondary" onClick={() => { setSelectedRole(role); setShowModal(true); }}
              disabled={roles[role].permission === "DENY"}>
              FileType
            </button>
          </div>
        </div>
      ))}

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title style={{ marginLeft: "auto" }}>SELECT FILE TYPES</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              gap: "10px",
              justifyContent: "center",
            }}
          >
            {fileTypes && fileTypes.length > 0 ? (
              fileTypes.map((fileType, index) => (
                <button
                  key={index}
                  onClick={() => handleFileTypeChange(fileType.name)}
                  style={{
                    padding: "10px",
                    backgroundColor: roles[selectedRole]?.extensions?.includes(fileType.name)
                      ? "#4CAF50"
                      : "#f1f1f1",
                    color: roles[selectedRole]?.extensions?.includes(fileType.name)
                      ? "white"
                      : "black",
                    border: "1px solid #ddd",
                    borderRadius: "5px",
                    cursor: "pointer",
                  }}
                >
                  {fileType.name}
                </button>
              ))
            ) : (
              <p>No file types available</p>
            )}
          </div>
        </Modal.Body>

        <Modal.Footer>
          <input
            type="text"
            placeholder="Add Extension"
            value={newExtension}
            onChange={(e) => setNewExtension(e.target.value)}
            style={{ marginRight: "10px" }}
          />
          <button className="btn btn-primary" onClick={handleAddExtension}>
            ADD 
          </button>
          <button className="btn btn-success" onClick={handleDone}>
            DONE
          </button>
        </Modal.Footer>
      </Modal>

      <div className="v">
        <button className="btn btn-success" onClick={updatePolicy}>
          Update
        </button>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}
    </div>
  );
};

export default PolicyUpdate;
