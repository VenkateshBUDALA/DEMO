import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const SystemCom = () => {
    const [systemDetails, setSystemDetails] = useState({
        systemname: '',
        ipaddress: '',
        macaddress: '',
        policy: '',
        user: '', // Combined username/id field
    });
    const navigate = useNavigate();

    const [policyNames, setPolicyNames] = useState([]); // Policy names
    const [userNames, setUserNames] = useState([]); // User details (username/userid format)
    const [error, setError] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setSystemDetails({ ...systemDetails, [name]: value });
    };

    // Fetch data on component mount
    useEffect(() => {
        const fetchData = async () => {
            try {
                // Fetching policy names
                const policyResponse = await axios.get("http://localhost:8080/api/policies/names");
                if (policyResponse.status === 200) {
                    setPolicyNames(policyResponse.data || []); // Set policy names
                } else {
                    setError("Failed to load policy names.");
                }
    
                // Fetching user names
                const userResponse = await axios.get("http://localhost:8080/api/users");
                if (userResponse.status === 200) {
                    const usernames = userResponse.data.map(user => user.username); // Extract usernames only
                    setUserNames(usernames || []); // Set usernames
                } else {
                    setError("Failed to load user details.");
                }
            } catch (error) {
                console.error("Error fetching data:", error);
                setError("Failed to load data. Please try again.");
            }
        };
    
        fetchData();
    }, []);
    
    const handleRegister = async (e) => {
        e.preventDefault();
    
        try {
            const payload = {
                systemname: systemDetails.systemname,
                ipaddress: systemDetails.ipaddress,
                macaddress: systemDetails.macaddress,
                policy: { policyName: systemDetails.policy }, // Send the policyName
                user: systemDetails.user, // Send the combined "username/userId"
            };
    
            console.log("Payload:", payload); // Debugging
    
            const response = await axios.post("http://localhost:8080/api/sys/register", payload);
    
            if (response.status === 201) {
                alert("Registration successful!");
                navigate('/SystemDetails');
            }
        } catch (error) {
            console.error("Error during registration:", error);
            setError(error.response?.data || "An error occurred. Please try again.");
        }
    };

    return (
        <div className="jumbotron p-5 my-5 bg-white rounded">
            <h1 className="v">SYSTEM REGISTRATION</h1>

            <form onSubmit={handleRegister}>
                <div className='v'>
                    <input
                        type="text"
                        name="systemname"
                        placeholder="System Name"
                        value={systemDetails.systemname}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className='v'>
                    <input
                        type="text"
                        name="ipaddress"
                        placeholder="IP Address"
                        value={systemDetails.ipaddress}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className='v'>
                    <input
                        type="text"
                        name="macaddress"
                        placeholder="MAC Address"
                        value={systemDetails.macaddress}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className='v'>
                    <select
                        style={{ width: '220px' }}
                        name="policy"
                        value={systemDetails.policy}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select Policy</option>
                        {policyNames.map((policy, index) => (
                            <option key={index} value={policy}>{policy}</option>
                        ))}
                    </select>
                </div>

                <div className='v'>
    <select
        style={{ width: '220px' }}
        name="user"
        value={systemDetails.user}
        onChange={handleChange}
        required
    >
        <option value="">Select Username</option>
        {userNames.map((username, index) => (
            <option key={index} value={username}>
                {username}
            </option>
        ))}
    </select>
</div>


                {error && <p style={{ color: 'red' }}>{error}</p>}

                <div className="v" style={{ display: 'flex', justifyContent: 'center' }}>
                    <button className="btn btn-success" type="submit">REGISTER</button>
                </div>
            </form>
        </div>
    );
};
export default SystemCom;
