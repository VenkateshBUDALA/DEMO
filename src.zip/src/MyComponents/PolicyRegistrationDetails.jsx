import React from 'react';
import { useLocation } from 'react-router-dom';

const PolicyRegistrationDetails = () => {
  const location = useLocation();
  const policy = location.state; // Retrieve the policy details passed via state

  if (!policy) {
    return <p>No policy data available.</p>;
  }

  return (
    <div className="container">
      <div className="card">
        <div className="card-header bg-primary text-white">
          <h2>Policy Registration Details</h2>
        </div>
        <div className="card-body">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>Field</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Policy Name</strong></td>
                <td>{policy.policyName || 'N/A'}</td>
              </tr>
              <tr>
                <td><strong>Registration Time</strong></td>
                <td>
                  {policy.registrationTime
                    ? new Date(policy.registrationTime).toLocaleString()
                    : 'Not Available'}
                </td>
              </tr>
              <tr>
                <td><strong>Roles</strong></td>
                <td>
                  {policy.roles && policy.roles.length > 0 ? (
                    <table className="table table-bordered">
                      <thead>
                        <tr>
                          <th>Role</th>
                          <th>Permission</th>
                          <th>File Types</th>
                        </tr>
                      </thead>
                      <tbody>
                        {policy.roles.map((role, index) => (
                          <tr key={index}>
                            <td>{role.role || 'N/A'}</td>
                            <td>{role.permission || 'N/A'}</td>
                            <td>
                              <ul style={{ listStyleType: 'none', padding: 0 }}>
                                {role.extensions && role.extensions.length > 0 ? (
                                  role.extensions.map((ext, idx) => (
                                    <li key={idx}>{ext}</li>
                                  ))
                                ) : (
                                  <li>No file types available</li>
                                )}
                              </ul>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    'No roles available'
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PolicyRegistrationDetails;
