import React, { useState, useEffect } from "react";
import { Modal } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./policy.css";
const PolicyCom = () => {
  const navigate = useNavigate();
  const [policyName, setPolicyName] = useState("");
  const [fileTypes, setFileTypes] = useState([]);
  const [roles, setRoles] = useState({
    group: { permission: "READ", extensions: [] },
    owner: { permission: "READ", extensions: [] },
    guest: { permission: "READ", extensions: [] },
  });
  const [selectedRole, setSelectedRole] = useState("group");
  const [showModal, setShowModal] = useState(false);
  const [newExtension, setNewExtension] = useState("");
  const [error, setError] = useState("");

  // Fetch File Extensions from the backend API
  const fetchFileExtensions = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/policies/filetypes");
      setFileTypes(response.data);
    } catch (error) {
      console.error("Error fetching file extensions:", error);
    }
  };

  useEffect(() => {
    fetchFileExtensions();
  }, []);

  // Handle File Type Selection
  const handleFileTypeChange = (fileType) => {
    setRoles((prevRoles) => {
      const updatedExtensions = prevRoles[selectedRole].extensions.includes(fileType)
        ? prevRoles[selectedRole].extensions.filter((ext) => ext !== fileType)
        : [...prevRoles[selectedRole].extensions, fileType];

      return {
        ...prevRoles,
        [selectedRole]: { ...prevRoles[selectedRole], extensions: updatedExtensions },
      };
    });
  };

  // Handle Done Button
  const handleDone = () => {
    if (roles[selectedRole].permission !== "DENY" && roles[selectedRole].extensions.length === 0) {
      setError("Please select at least one file type.");
      return;
    }
    setError("");
    setShowModal(false);
  };

  // Handle Register Policy
  const handleRegisterPolicy = async () => {
    if (!policyName.trim()) {
        setError("Policy name is required.");
        return;
    }

    const hasExtensions = Object.keys(roles).every((role) => {
        return roles[role].permission === "DENY" || roles[role].extensions.length > 0;
    });

    if (!hasExtensions) {
        setError("Each role must have at least one file type selected, unless permission is DENY.");
        return;
    }

    setError("");

    const policyData = {
        policyName: policyName,
        roles: Object.keys(roles).map((role) => ({
            role,
            permission: roles[role].permission || "READ", // Default to READ if permission is not set
            extensions: roles[role].extensions,
        })),
    };

    try {
        const response = await axios.post("http://localhost:8080/api/policies", policyData);
        alert("Policy registered successfully!");
        navigate("/PolicyDetails");

        // Reset the form
        setPolicyName("");
        setRoles({
            group: { permission: "READ", extensions: [] },
            owner: { permission: "READ", extensions: [] },
            guest: { permission: "READ", extensions: [] },
        });
    } catch (error) {
        console.error("Error registering policy:", error);
        if (error.response) {
            // Log detailed error response from backend
            console.error("Backend error:", error.response.data);
            setError(`Failed to register the policy: ${error.response.data}`);
        } else {
            setError("Failed to register the policy. Please try again.");
        }
    }
};

  // Handle adding a new extension
  const handleAddExtension = async () => {
    if (newExtension.trim() && !fileTypes.some(ft => ft.name === newExtension.trim())) {
      try {
        const newFileType = { name: newExtension.trim() };
        await axios.post("http://localhost:8080/api/policies/filetypes", newFileType);
        setFileTypes((prev) => [...prev, newFileType]);
        setNewExtension("");
      } catch (error) {
        console.error("Error adding new extension:", error);
        alert("Failed to add new extension. Please try again.");
      }
    } else if (fileTypes.some(ft => ft.name === newExtension.trim())) {
      alert("Extension already exists!");
    }
  };

  return (
    <div className="jumbotron p-5 my-5 bg-white rounded">
      <h1 className="v">POLICY REGISTRATION</h1>

      <div className="v">
        <input
          type="text"
          placeholder="Policy Name"
          value={policyName}
          onChange={(e) => setPolicyName(e.target.value)}
          required
        />
      </div>

      {["group", "owner", "guest"].map((role) => (
        <div key={role}>
          <label style={{ marginTop: "20px", marginRight: "250px" }}>{role.toUpperCase()}</label>
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              gap: "20px",
              marginTop: "-30px",
              marginLeft: "130px",
              alignItems: "center",
            }}
          >
            <select
              value={roles[role].permission}
              onChange={(e) =>
                setRoles({ ...roles, [role]: { ...roles[role], permission: e.target.value } })
              }
            >
              <option>READ</option>
              <option>WRITE</option>
              <option>BOTH</option>
              <option>DENY</option>
            </select>
            <button
              className="btn btn-secondary"
              style={{ borderRadius: "15px" }}
              onClick={() => {
                setSelectedRole(role);
                setShowModal(true);
              }}
              disabled={roles[role].permission === "DENY"}
            >
              FileType
            </button>
          </div>
        </div>
      ))}

      {error && <p style={{ color: "red", textAlign: "center" }}>{error}</p>}

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Select File Types</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "10px", justifyContent: "center" }}>
            {fileTypes.map((fileType, index) => (
              <button
                key={index}
                onClick={() => handleFileTypeChange(fileType.name)}
                style={{
                  padding: "10px",
                  backgroundColor: roles[selectedRole]?.extensions?.includes(fileType.name)
                    ? "#4CAF50"
                    : "#f1f1f1",
                  color: roles[selectedRole]?.extensions?.includes(fileType.name) ? "white" : "black",
                  border: "1px solid #ddd",
                  borderRadius: "5px",
                  cursor: "pointer",
                }}
              >
                {fileType.name}
              </button>
            ))}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <input
            type="text"
            placeholder="Add new extension (e.g., json)"
            value={newExtension}
            onChange={(e) => setNewExtension(e.target.value)}
            style={{
              padding: "10px",
              border: "1px solid #ddd",
              borderRadius: "5px",
              marginRight: "10px",
              width: "200px",
            }}
          />
          <button className="btn btn-primary" onClick={handleAddExtension}>
            Add
          </button>
          <button className="btn btn-success" onClick={handleDone}>
            Done
          </button>
        </Modal.Footer>
      </Modal>

      <div className="v">
        <button
          style={{ display: "flex", margin: "auto", justifyContent: "center" }}
          type="button"
          onClick={handleRegisterPolicy}
          className="btn btn-success"
        >
          Register
        </button>
      </div>
    </div>
  );
};
export default PolicyCom;
