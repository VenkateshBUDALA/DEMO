import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

const UpdateUser = () => {
  const navigate = useNavigate();
  const { userid } = useParams(); // Extract `userid` from URL params
  const [user, setUser] = useState({
    username: '',
    department: '',
    unit: '',
    status: '',
    password: '',
    registrationTime: '',
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Fetch user details when the component mounts
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem('authToken'); // Get token from localStorage
        const response = await axios.get(`http://localhost:8080/api/users/${userid}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (response.status === 200) {
          const { username, departmentDetails, registrationTime } = response.data;
          setUser({
            username,
            department: departmentDetails.department,
            unit: departmentDetails.unit,
            status: departmentDetails.status,
            password: '', // Keep password empty for security reasons
            registrationTime,
          });
        } else {
          setError('Failed to load user details. Please try again.');
        }
      } catch (err) {
        console.error('Error fetching user details:', err);
        setError('Failed to load user details. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [userid]);

  // Handle form submission for updating user details
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const token = localStorage.getItem('authToken'); // Get token from localStorage
      const updatedUser = {
        ...user,
        departmentDetails: {
          department: user.department,
          unit: user.unit,
          status: user.status,
        },
      };

      const response = await axios.put(
        `http://localhost:8080/api/users/${userid}`,
        updatedUser,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.status === 200) {
        alert('User updated successfully!');
        navigate('/UserDetails'); // Navigate to the user details page
      } else {
        setError('Failed to update user details. Please try again.');
      }
    } catch (err) {
      console.error('Error updating user:', err);
      setError('An error occurred while updating user details.');
    }
  };

  // Handle input changes for the form
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prevUser) => ({ ...prevUser, [name]: value }));
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="container d-flex justify-content-center align-items-center">
      <div className="jumbotron p-5 my-5 bg-light rounded" style={{ width: '50%' }}>
        <h2 className="text-center">Update User</h2>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="username"
            placeholder="Enter username"
            value={user.username}
            onChange={handleChange}
            style={inputStyle}
          />
          <input
            type="text"
            name="department"
            placeholder="Enter department"
            value={user.department}
            onChange={handleChange}
            style={inputStyle}
          />
          <input
            type="text"
            name="unit"
            placeholder="Enter unit"
            value={user.unit}
            onChange={handleChange}
            style={inputStyle}
          />
          <input
            type="password"
            name="password"
            placeholder="Enter password"
            value={user.password}
            onChange={handleChange}
            style={inputStyle}
          />
          <select
            name="status"
            value={user.status}
            onChange={handleChange}
            style={inputStyle}
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
          <button type="submit" style={buttonStyle}>
            Update
          </button>
        </form>
      </div>
    </div>
  );
};
// Common input style
const inputStyle = {
  display: 'block',
  width: '100%',
  padding: '10px',
  marginBottom: '15px',
  border: '1px solid #ccc',
  borderRadius: '4px',
};

// Button style
const buttonStyle = {
  padding: '10px 20px',
  backgroundColor: '#007bff',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
  width: '100%',
};

export default UpdateUser;
