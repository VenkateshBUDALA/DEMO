import React, { useState, useEffect } from 'react';
import Pagination from 'react-js-pagination'; // Ensure this package is installed
import { useNavigate } from 'react-router-dom';
import axios from 'axios'; // For making API calls

const PolicyDetails = () => {
  const navigate = useNavigate();
  const [policies, setPolicies] = useState([]);
  const [filteredPolicies, setFilteredPolicies] = useState([]);
  const [activePage, setActivePage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const policiesPerPage = 2;

  useEffect(() => {
    // Fetch policy details from the backend
    const fetchPolicies = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/policies');
        console.log('API Response:', response.data);
        if (response.data && response.data.data) {
          setPolicies(response.data.data);
          setFilteredPolicies(response.data.data);
        } else {
          console.error('Unexpected API response:', response.data);
        }
      } catch (error) {
        console.error('Error fetching policies:', error);
        alert('Failed to fetch policies. Please try again later.');
      }
    };

    fetchPolicies();
  }, []);

  // Pagination logic
  const indexOfLastPolicy = activePage * policiesPerPage;
  const indexOfFirstPolicy = indexOfLastPolicy - policiesPerPage;
  const currentPolicies = filteredPolicies.slice(indexOfFirstPolicy, indexOfLastPolicy);

  const handlePageChange = (pageNumber) => {
    setActivePage(pageNumber);
  };

  const handleAddPolicy = () => {
    navigate('/PolicyCom');
  };
  const handleMoreDetails = (policy) => {
    navigate(`/PolicyRegistrationDetails`, { state: policy }); // Passing policy object in state
  };
  
  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
    const filtered = policies.filter((policy) =>
      policy.policyName.toLowerCase().includes(event.target.value.toLowerCase())
    );
    setFilteredPolicies(filtered);
    setActivePage(1);
  };

  const handleUpdatePolicy = (policyId) => {
    navigate(`/PolicyUpdate/${policyId}`);
  };

  const handleDeletePolicy = async (policyId) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this policy?');
    if (confirmDelete) {
      try {
        await axios.delete(`http://localhost:8080/api/policies/${policyId}`);
        setPolicies(policies.filter((policy) => policy.id !== policyId));
        setFilteredPolicies(filteredPolicies.filter((policy) => policy.id !== policyId));
        alert('Policy deleted successfully!');
      } catch (error) {
        console.error('Error deleting policy:', error);
        alert('Failed to delete policy');
      }
    }
  };

  return (
    <div className="container-fluid p-4" style={{ maxWidth: '1200px', margin: '0 auto' }}>
      <div className="row my-3">
        <div className="col-md-4">
          <h4>POLICY DETAILS</h4>
        </div>
        <div className="col-md-4">
          <input
            type="text"
            className="form-control"
            placeholder="Search by Policy Name"
            value={searchTerm}
            onChange={handleSearch}
            style={{ width: '300px' }}
          />
        </div>
        <div className="col-md-4 text-end">
          <button className="btn btn-primary" onClick={handleAddPolicy}>
            Add Policy
          </button>
        </div>
      </div>

      {/* Policy Table */}
      <div className="row">
        <div className="col-md-12">
          <div className="table-responsive" style={{ maxHeight: '400px', overflowY: 'auto' }}>
            <table className="table table-bordered table-hover">
              <thead className="thead-dark">
                <tr>
                  <th>Sr. No</th>
                  <th>Policy Name</th>
                  <th>Role</th>
                  <th>Permissions</th>
                  <th>File Types</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentPolicies.length > 0 ? (
                  currentPolicies.map((policy, index) => (
                    <tr key={policy.id}>
                      <td>{indexOfFirstPolicy + index + 1}</td>
                      <td>{policy.policyName}</td>
                      <td>
                        {policy.roles && policy.roles.length > 0 ? (
                          <ul style={{ listStyleType: 'none', paddingLeft: '0' }}>
                            {policy.roles.map((role, idx) => (
                              <li key={idx}>{role.role}</li>
                            ))}
                          </ul>
                        ) : (
                          'No roles available'
                        )}
                      </td>
                      <td>
                        {policy.roles && policy.roles.length > 0 ? (
                          <ul style={{ listStyleType: 'none', paddingLeft: '0' }}>
                            {policy.roles.map((role, idx) => (
                              <li key={idx}>{role.permission}</li>
                            ))}
                          </ul>
                        ) : (
                          'No permissions available'
                        )}
                      </td>
                      <td>
                        {policy.roles && policy.roles.length > 0 ? (
                          <ul style={{ listStyleType: 'none', paddingLeft: '0' }}>
                            {policy.roles.map((role, idx) =>
                              role.extensions.length > 0 ? (
                                role.extensions.map((ext, subIdx) => <li key={subIdx}>{ext}</li>)
                              ) : (
                                <li key={idx}>No extensions</li>
                              )
                            )}
                          </ul>
                        ) : (
                          'No file types available'
                        )}
                      </td>
                      <td>
                      <button
  className="btn btn-success btn-sm me-2"
  onClick={() => handleMoreDetails(policy)}
>
  MoreDetails
</button>

                        <button className="btn btn-warning btn-sm me-2" onClick={() => handleUpdatePolicy(policy.id)}>
                          Update
                        </button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDeletePolicy(policy.id)}>
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center">
                      No policies available
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      <div className="row">
        <div className="col-12 d-flex justify-content-end">
          <Pagination
            activePage={activePage}
            itemsCountPerPage={policiesPerPage}
            totalItemsCount={filteredPolicies.length}
            pageRangeDisplayed={5}
            onChange={handlePageChange}
            itemClass="page-item"
            linkClass="page-link"
          />
        </div>
      </div>
    </div>
  );
};

export default PolicyDetails;
