import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

const UpdateUsb = () => {
  const { usbId } = useParams(); // Get the usbId from the URL
  console.log('usbId:', usbId); // This should log the actual usbId from the URL

  const navigate = useNavigate();

  const [usb, setUsb] = useState({
    usbname: '',
    uuid: '',
    serialNumber: '',
    user: '',
    status: 'INACTIVE',
  });
  const [userNames, setUserNames] = useState([]);
  const [serialNumbers, setSerialNumbers] = useState([]);
  const [uuids, setUuids] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    console.log('Fetching USB details with ID:', usbId); // This should log a valid usbId
    axios.get(`http://localhost:8082/api/usb/usbDetails/${usbId}`)
      .then(response => {
        console.log('USB Details:', response.data);
        setUsb(response.data);
      })
      .catch(error => {
        console.error('Error fetching USB details:', error.response || error.message);
        setError('Failed to load USB details.');
      });
  }, [usbId]);
  

  useEffect(() => {
    fetchUserNames();
    fetchSerialNumbers();
    fetchUuids();
  }, []);

  const fetchUserNames = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/users");
      if (response.status === 200) {
        const usernames = response.data.map(user => user.username);
        setUserNames(usernames);
      } else {
        setError("Failed to load user details.");
      }
    } catch (error) {
      console.error("Error fetching usernames:", error);
      setError("Failed to load usernames.");
    }
  };

  const fetchSerialNumbers = async () => {
    try {
      const response = await axios.get("http://localhost:8082/api/usb/serials");
      if (response.status === 200) {
        setSerialNumbers(response.data);
      }
    } catch (error) {
      console.error("Error fetching serial numbers:", error);
      setError("Failed to load serial numbers.");
    }
  };

  const fetchUuids = async () => {
    try {
      const response = await axios.get("http://localhost:8082/api/usb/names");
      if (response.status === 200) {
        setUuids(response.data);
      }
    } catch (error) {
      console.error("Error fetching UUIDs:", error);
      setError("Failed to load UUIDs.");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.put(`http://localhost:8082/api/usb/usbDetails/${usbId}`, usb)
      .then(() => {
        alert('USB updated successfully!');
        navigate('/usbDetails'); // Redirect to the USB details page
      })
      .catch(error => {
        console.error('Error updating USB:', error);
        alert('Error updating USB!');
      });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUsb(prevUsb => ({
      ...prevUsb,
      [name]: value,
    }));
  };

  return (
    <div className="jumbotron p-5 my-5 bg-white rounded">
      <h1>USB UPDATION</h1>
      <form onSubmit={handleSubmit}>
        <div className="v">
          <input
            type="text"
            placeholder="USB Name"
            name="usbname"
            value={usb.usbname}
            onChange={handleChange}
            required
          />
        </div>

        <div className="v">
          <select
            name="user"
            value={usb.user}
            onChange={handleChange}
            style={{ width: '220px' }}
            required
          >
            <option value="">Select Username</option>
            {userNames.map((username, index) => (
              <option key={index} value={username}>{username}</option>
            ))}
          </select>
        </div>

        <div className="v">
          <select
            name="serialNumber"
            value={usb.serialNumber}
            onChange={handleChange}
            style={{ width: '150px', marginRight: '70px' }}
          >
            <option value="">Select Serial Number</option>
            {serialNumbers.map((serial, index) => (
              <option key={index} value={serial}>{serial}</option>
            ))}
          </select>
        </div>

        <div className="v">
          <select
            name="uuid"
            value={usb.uuid}
            onChange={handleChange}
            style={{ width: '150px', marginRight: '70px' }}
          >
            <option value="">Select UUID</option>
            {uuids.map((uuid, index) => (
              <option key={index} value={uuid}>{uuid}</option>
            ))}
          </select>
        </div>
        <button 
                    className="btn btn-secondary p-3" 
                    onClick={() => { 
                        fetchSerialNumbers(); 
                        fetchUuids(); 
                    }}
                    style={{ marginTop: '-110px', marginLeft: '170px' }}
                >
                    Fetch
                </button>
        <div>
          <button type="submit" className="btn btn-success">UPDATE</button>
        </div>
      </form>

      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
};
export default UpdateUsb;
