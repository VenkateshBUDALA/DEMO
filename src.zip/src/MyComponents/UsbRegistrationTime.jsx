import React from 'react';
import { useLocation } from 'react-router-dom';

const UsbRegistrationTime = () => {
  const location = useLocation();
  const usb = location.state; // Assuming USB details are passed through the route state

  if (!usb) {
    return <p>No USB data available.</p>;
  }

  return (
    <div className="container p-4">
      <div className="card my-5">
        <div className="card-header bg-primary text-white">
          <h2>USB Registration Details</h2>
        </div>
        <div className="card-body">
          <p><strong>USB Name:</strong> {usb.usbname || 'N/A'}</p>
          <p><strong>UUID:</strong> {usb.uuid || 'N/A'}</p>
          <p><strong>Serial Number:</strong> {usb.serialNumber || 'N/A'}</p>
          <p><strong>User:</strong> {usb.user || 'N/A'}</p>
          <p><strong>Status:</strong> {usb.status || 'N/A'}</p>
          <p>
            <strong>Registration Time:</strong>{' '}
            {usb.registrationTime
              ? new Date(usb.registrationTime).toLocaleString()
              : 'Not Available'}
          </p>
          <p>
            <strong>Formatted Registration Time:</strong>{' '}
            {usb.formattedRegistrationTime || 'Not Available'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default UsbRegistrationTime;
