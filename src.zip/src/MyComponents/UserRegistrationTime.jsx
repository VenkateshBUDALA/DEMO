import React from 'react';
import { useLocation } from 'react-router-dom';

const UserRegistrationTime = () => {
  const location = useLocation();
  const user = location.state;

  if (!user) {
    return <p>No user data available.</p>;
  }

  return (
   <div className="container p-4">
  <div className="card my-5">
    <div className="card-header bg-primary text-black">
      <h2>User Registration Details</h2>
    </div>
    <div className="card-body">
      <p><strong>Username:</strong> {user.username || 'N/A'}</p>
      <p><strong>Department:</strong> {user.departmentDetails?.department || 'N/A'}</p>
      <p><strong>Unit:</strong> {user.departmentDetails?.unit || 'N/A'}</p>
      <p><strong>Status:</strong> {user.departmentDetails?.status || 'N/A'}</p>
      <p>
        <strong>Registration Time:</strong>{' '}
        {user.registrationTime
          ? new Date(user.registrationTime).toLocaleString()
          : 'Not Available'}
      </p>
    </div>
  </div>
</div>

  );
};

export default UserRegistrationTime;
