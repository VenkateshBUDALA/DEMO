import React, { useState, useEffect } from 'react';

export default function RemovableStorage() {
  const [userStatus, setUserStatus] = useState(null);
  const [systemStatus, setSystemStatus] = useState(null);
  const [usbStatus, setUsbStatus] = useState(null);

  // Simulate fetching data from an API
  useEffect(() => {
    // Fetch user active status
    setUserStatus('Active'); // Replace with API call for real data

    // Fetch system active status
    setSystemStatus('Active'); // Replace with API call for real data

    // Fetch USB status
    setUsbStatus('Connected'); // Replace with API call for real data
  }, []);

  return (
    <div className="container">
      <h1 className="text-center my-4">!.REMOVABLE USB STORAGE DEVICE.!</h1>
      
      <div className="row justify-content-center mb-3">
        <div
          style={{ height: '200px' }}
          className="col-lg-3 col-md-5 col-sm-12 mx-2 bg-white rounded d-flex align-items-center justify-content-center shadow-sm"
        >
          <h3>User Active Status: {userStatus || 'Loading...'}</h3>
        </div>
        <div
          style={{ height: '200px' }}
          className="col-lg-3 col-md-5 col-sm-12 mx-2 bg-white rounded d-flex align-items-center justify-content-center shadow-sm"
        >
          <h3>System Active Status: {systemStatus || 'Loading...'}</h3>
        </div>
        <div
          style={{ height: '200px' }}
          className="col-lg-3 col-md-5 col-sm-12 mx-2 bg-white rounded d-flex align-items-center justify-content-center shadow-sm"
        >
          <h3>USB Status: {usbStatus || 'Loading...'}</h3>
        </div>
      </div>

      {/* Graph Removed */}
      <div className="row">
        <div
          style={{
            height: '250px',
            display: 'flex',
            justifyContent: 'center',
            marginTop: '10px',
            marginBottom: '10px',
          }}
          className="col-md-12 bg-white rounded shadow-sm d-flex align-items-center justify-content-center"
        >
          <h3>No Graph Data Available</h3>
        </div>
      </div>
    </div>
  );
}
