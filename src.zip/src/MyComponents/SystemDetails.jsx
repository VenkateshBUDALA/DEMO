import React, { useState, useEffect } from 'react';
import Pagination from 'react-js-pagination';
import { useNavigate } from 'react-router-dom';

const SystemDetails = () => {
  const navigate = useNavigate();
  const [systems, setSystems] = useState([]);
  const [filteredSystems, setFilteredSystems] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activePage, setActivePage] = useState(1);
  const systemsPerPage = 5;

  // Fetch systems data from backend
  useEffect(() => {
    const fetchSystems = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/sys'); // Updated endpoint to match backend
        if (!response.ok) {
          throw new Error(`Error fetching systems: ${response.statusText}`);
        }
        const data = await response.json();
        setSystems(data);
        setFilteredSystems(data);
      } catch (error) {
        console.error('Error fetching systems:', error);
      }
    };

    fetchSystems();
  }, []);

  // Handle search input
  const handleSearch = (e) => {
    const term = e.target.value.toLowerCase();
    setSearchTerm(term);
    if (term === '') {
      setFilteredSystems(systems);
    } else {
      setFilteredSystems(
        systems.filter((system) =>
          system.systemname.toLowerCase().includes(term) // Updated to match backend field name
        )
      );
    }
  };

  // Pagination logic
  const indexOfLastSystem = activePage * systemsPerPage;
  const indexOfFirstSystem = indexOfLastSystem - systemsPerPage;
  const currentSystems = filteredSystems.slice(indexOfFirstSystem, indexOfLastSystem);

  const handlePageChange = (pageNumber) => {
    setActivePage(pageNumber);
  };

  const handleAddSystem = () => {
    navigate('/SystemCom');
  };

  const handleMoreDetails = (system) => {
    navigate('/SystemRegistrationDetails', { state: { ...system } });
  };
  const handleEditSystem = (systemId) => {
    navigate(`/update-system/${systemId}`);
  };
  

  const handleDeleteSystem = async (systemId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this system?");
    if (confirmDelete) {
      try {
        const response = await fetch(`http://localhost:8080/api/sys/${systemId}`, { // Updated endpoint
          method: 'DELETE',
        });

        if (response.ok) {
          setSystems(systems.filter((system) => system.id !== systemId));
          setFilteredSystems(filteredSystems.filter((system) => system.id !== systemId));
        } else {
          console.error('Error deleting system:', response.statusText);
        }
      } catch (error) {
        console.error('Error deleting system:', error);
      }
    }
  };

  return (
    <div className="container-fluid p-4" style={{ maxWidth: '1200px', margin: '0 auto' }}>
      <div className="row">
        <div className="col-md-9"></div>
        <div className="col-md-3">
          <button className="btn btn-danger my-3">U N B L O C K</button>
        </div>
      </div>

      <div className="row my-3">
        <div className="col-md-4">
          <h4>SYSTEM DETAILS</h4>
        </div>
        <div className="col-md-4">
          <input
            type="text"
            className="form-control"
            placeholder="Search by System Name"
            value={searchTerm}
            onChange={handleSearch}
            style={{ width: '300px' }}
          />
        </div>
        <div className="col-md-4">
          <button className="btn btn-primary" onClick={handleAddSystem}>
            Add System
          </button>
        </div>
      </div>

      {/* System Table */}
      <div className="row">
        <div className="col-md-12">
          <div
            className="table-responsive"
            style={{
              maxHeight: '400px',
              overflowY: 'auto',
            }}
          >
            <table className="table table-bordered table-hover">
              <thead className="thead-dark">
                <tr>
                  <th style={{ width: '10%' }}>Sr. No</th>
                  <th style={{ width: '15%' }}>System Name</th>
                  <th style={{ width: '15%' }}>IP Address</th>
                  <th style={{ width: '15%' }}>MAC Address</th>
                  <th style={{ width: '10%' }}>Status</th>
                  <th style={{ width: '30%' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentSystems.map((system, index) => (
                  <tr key={system.id}>
                    <td>{indexOfFirstSystem + index + 1}</td>
                    <td>{system.systemname}</td>
                    <td>{system.ipaddress}</td>
                    <td>{system.macaddress}</td>
                    <td>{system.status}</td>
                    <td>
                      <button
                        className="btn btn-success btn-sm me-2"
                        onClick={() => handleMoreDetails(system)}
                      >
                        More Details
                      </button>
                      <button
                        className="btn btn-warning btn-sm me-2"
                        onClick={() => handleEditSystem(system.id)}
                      >
                        Update
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDeleteSystem(system.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      <div className="row">
        <div className="col-12 d-flex justify-content-end">
          <Pagination
            activePage={activePage}
            itemsCountPerPage={systemsPerPage}
            totalItemsCount={filteredSystems.length}
            pageRangeDisplayed={5}
            onChange={handlePageChange}
            itemClass="page-item"
            linkClass="page-link"
          />
        </div>
      </div>
    </div>
  );
};

export default SystemDetails;
