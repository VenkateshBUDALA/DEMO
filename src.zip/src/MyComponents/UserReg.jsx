import React, { useState } from 'react';
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const UserReg = () => {
    const [username, setUsername] = useState('');
    const [dept, setDept] = useState('');
    const [unit, setUnit] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    // Predefined department names
    const departments = [
        'Human Resources',
        'Finance',
        'Engineering',
        'Sales',
        'Marketing',
        'IT',
        'Customer Support',
        'Operations',
    ];

    const handleRegister = async () => {
        if (username.length < 5 || password.length < 8 || dept.length === 0 || unit.length === 0) {
            setError('Please ensure all fields are valid.');
            return;
        }
        setError('');

        try {
            const response = await axios.post('http://localhost:8080/api/register', {
                username,
                password,
                departmentDetails: {
                    department: dept,
                    unit,
                },
            });

            if (response.status === 200) {
                alert('Registration successful!');
                navigate('/userDetails'); // Navigate to the UserDetails page after registration
            } else {
                setError('Registration failed. Please try again.');
            }
        } catch (error) {
            console.error('Error during registration:', error);
            const errorMessage =
                error.response?.data?.message || 'An unexpected error occurred. Please try again.';
            setError(errorMessage);
        }
    };

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    return (
        <div className="jumbotron p-5 my-5 bg-white rounded">
            <h1 className="v">USER REGISTRATION</h1>
            <div className="v">
                <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />
            </div>
            <div className="v">
                <select
                    value={dept}
                    onChange={(e) => setDept(e.target.value)}
                    required
                    style={{  width: '60%' }}
                >
                    <option value="" disabled>Select Department</option>
                    {departments.map((department, index) => (
                        <option key={index} value={department}>
                            {department}
                        </option>
                    ))}
                </select>
            </div>
            <div className="v">
                <input
                    type="text"
                    placeholder="Unit"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    required
                />
            </div>
            <div className="v">
                <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <span onClick={togglePasswordVisibility} className="Eye">
                    {showPassword ? <FaEye /> : <FaEyeSlash />}
                </span>
            </div>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <div className="v" style={{ display: 'flex', justifyContent: 'center' }}>
                <button className="btn btn-success" onClick={handleRegister}>
                    REGISTER
                </button>
            </div>
        </div>
    );
};

export default UserReg;
