import React, { useState, useEffect } from 'react';
import Pagination from 'react-js-pagination'; // Ensure this package is installed
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const UsbDetails = () => {
  const navigate = useNavigate();
  const [usbDetails, setUsbDetails] = useState([]);
  const [activePage, setActivePage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const usersPerPage = 3;

  // Fetch USB details from the backend
  useEffect(() => {
    axios.get('http://localhost:8082/api/usb/usbDetails') // Replace with your backend API endpoint
      .then(response => {
        setUsbDetails(response.data); // Assuming the backend returns an array of USB details
      })
      .catch(error => {
        console.error('Error fetching USB details:', error);
        console.log(";;;;");
      });
  }, []);

  // Filter USB details based on search query
  const filteredUsbDetails = usbDetails.filter(usb =>
    usb.usbname.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Pagination logic
  const indexOfLastUser = activePage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;
  const currentUsbDetails = filteredUsbDetails.slice(indexOfFirstUser, indexOfLastUser);

  const handlePageChange = (pageNumber) => {
    setActivePage(pageNumber);
  };

  const handleAddUsb = () => {
    navigate('/UsbCom');
  };

  const handleMoreDetails = (usb) => {
    navigate('/usbRegistrationTime', { state: { ...usb } });
  };

  const handleUpdateUsb = (usbId) => {
    navigate(`/updateUsb/${usbId}`);
  };

  const handleDelete = (id) => {
    const isConfirmed = window.confirm('Are you sure you want to delete this USB?');

    if (isConfirmed) {
      axios.delete(`http://localhost:8082/api/usb/usbDetails/${id}`)
        .then(response => {
          setUsbDetails(usbDetails.filter(usb => usb.id !== id));
          alert('USB deleted successfully!');
        })
        .catch(error => {
          console.error('Error deleting USB:', error);
          alert('Error deleting USB!');
        });
    }
  };

  // Highlight matching text in usbname
  const highlightText = (text, query) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, index) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <span key={index} style={{ backgroundColor: 'yellow' }}>{part}</span>
      ) : (
        part
      )
    );
  };

  return (
    <div className="container-fluid p-4" style={{ maxWidth: '1200px', margin: '0 auto' }}>
      <div className="row">
        <div className="col-md-9"></div>
        <div className="col-md-3">
          <button style={{ marginLeft: '20px' }} className="btn btn-danger my-3">
            U N B L O C K
          </button>
        </div>
      </div>
      <div className="row my-3">
        <div className="col-md-4">
          <h4>USB DETAILS</h4>
        </div>
        <div className="col-md-4">
          <input
            type="text"
            className="form-control"
            placeholder="Search"
            style={{ width: '300px' }}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <button className="btn btn-primary" onClick={handleAddUsb}>
            Add Usb
          </button>
        </div>
      </div>

      {/* USB Table */}
      <div className="row">
        <div className="col-md-12">
          <div
            className="table-responsive"
            style={{
              maxHeight: '400px',
              overflowY: 'auto',
            }}
          >
            <table className="table table-bordered table-hover">
              <thead className="thead-dark">
                <tr>
                  <th style={{ width: '10%' }}>Sr. No</th>
                  <th style={{ width: '10%' }}>Serial Number</th>
                  <th style={{ width: '10%' }}>Status</th>
                  <th style={{ width: '15%' }}>USB Name</th>
                  <th style={{ width: '10%' }}>User</th>
                  <th style={{ width: '10%' }}>UUID Name</th>
                  <th style={{ width: '50%' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentUsbDetails.map((usb, index) => (
                  <tr key={usb.id}>
                    <td>{indexOfFirstUser + index + 1}</td>
                    <td>{usb.serialNumber}</td>
                    <td>{usb.status}</td>
                    <td>{highlightText(usb.usbname, searchQuery)}</td>
                    <td>{usb.user}</td>
                    <td>{usb.uuid}</td>
                    <td>
                      <button className="btn btn-success btn-sm me-2" onClick={() => handleMoreDetails(usb)}>More Details</button>
                      <button className="btn btn-warning btn-sm me-1" style={{ marginTop: '5px' }} onClick={() => handleUpdateUsb(usb.id)}>Update</button>
                      <button className="btn btn-danger btn-sm" style={{ marginTop: '5px' }} onClick={() => handleDelete(usb.id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      <div className="row">
        <div className="col-12 d-flex justify-content-end">
          <Pagination
            activePage={activePage}
            itemsCountPerPage={usersPerPage}
            totalItemsCount={filteredUsbDetails.length}
            pageRangeDisplayed={5}
            onChange={handlePageChange}
            itemClass="page-item"
            linkClass="page-link"
          />
        </div>
      </div>
    </div>
  );
};
export default UsbDetails;
