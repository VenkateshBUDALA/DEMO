import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../App.css';

const NavBarCom = () => {
    const [activeButton, setActiveButton] = useState('/'); // Set the default active button

    const handleButtonClick = (path) => {
        setActiveButton(path); // Update the active button when clicked
    };

    return (
        <nav style={{ display: 'flex', flexDirection: 'column', marginTop: '30px' }}>
   <Link
  to="/"
  className={`navbar-button button-user ${activeButton === '/' ? 'active' : ''}`}
  onClick={() => handleButtonClick('/')}
  style={{
    marginTop: '20px',
    fontSize: '12px', // Text size
    padding: '12px 15px', // Increased padding for larger button size
    //display: 'inline-block', // Ensures the button behaves like a block element for easy size adjustment
  }}
>
  D A S H  B O A R D
</Link>


        <Link
          to="/userDetails"
          className={`navbar-button button-user ${activeButton === '/userDetails' ? 'active' : ''}`}
          onClick={() => handleButtonClick('/userDetails')}
          style={{ marginTop: '20px' }} // Increased margin
        >
          U S E R
        </Link>
        <Link
          to="/systemDetails"
          className={`navbar-button button-system ${activeButton === '/systemDetails' ? 'active' : ''}`}
          onClick={() => handleButtonClick('/systemDetails')}
          style={{ marginTop: '20px' }} // Increased margin
        >
          S Y S T E M
        </Link>
        <Link
          to="/UsbDetails"
          className={`navbar-button button-usb ${activeButton === '/UsbDetails' ? 'active' : ''}`}
          onClick={() => handleButtonClick('/UsbDetails')}
          style={{ marginTop: '20px' }} // Increased margin
        >
          U S B
        </Link>
        <Link
          to="/PolicyDetails"
          className={`navbar-button button-policy ${activeButton === '/PolicyDetails' ? 'active' : ''}`}
          onClick={() => handleButtonClick('/PolicyDetails')}
          style={{ marginTop: '20px' }} // Increased margin
        >
          P O L I C Y
        </Link>
      </nav>
      
    );
};

export default NavBarCom;
