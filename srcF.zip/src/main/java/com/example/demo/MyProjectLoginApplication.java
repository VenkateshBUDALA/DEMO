package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyProjectLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyProjectLoginApplication.class, args);
	}

}
