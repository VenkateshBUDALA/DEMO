package com.example.demo.service;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public User registerUser(User user) {
     user.setPassword(passwordEncoder.encode(user.getPassword()));
    	//user.setPassword(user.getPassword());
    	
        return userRepository.save(user);
    }
    public boolean loginUser(String username, String password) {
        return userRepository.findByUsername(username)
       
                .map(user -> passwordEncoder.matches(password, user.getPassword()))
                .orElse(false);
    }
}
